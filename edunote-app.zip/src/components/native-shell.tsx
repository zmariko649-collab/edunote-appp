import { useEffect } from "react";
import { useRouter } from "@tanstack/react-router";
import { isNativeApp } from "@/lib/native";
import { useNetworkSync } from "@/lib/sync-queue";

/**
 * Comportements natifs Android : bouton Retour matériel, blocage du zoom
 * double-tap / rebond de scroll, et synchronisation réseau automatique.
 */
export function NativeShell() {
  const router = useRouter();
  useNetworkSync();

  // Blocage du zoom double-tap et du pinch-zoom dans la WebView.
  useEffect(() => {
    if (typeof document === "undefined") return;
    let lastTouch = 0;
    const onTouchEnd = (e: TouchEvent) => {
      const now = Date.now();
      if (now - lastTouch <= 300) e.preventDefault();
      lastTouch = now;
    };
    const onGesture = (e: Event) => e.preventDefault();
    document.addEventListener("touchend", onTouchEnd, { passive: false });
    document.addEventListener("gesturestart", onGesture as EventListener);
    return () => {
      document.removeEventListener("touchend", onTouchEnd);
      document.removeEventListener("gesturestart", onGesture as EventListener);
    };
  }, []);

  // Touche Retour Android : ferme d'abord une modale ouverte, sinon navigue en arrière.
  useEffect(() => {
    if (!isNativeApp()) return;
    let remove: (() => void) | undefined;

    void (async () => {
      const [{ App }] = await Promise.all([import("@capacitor/app")]);
      const handle = await App.addListener("backButton", ({ canGoBack }) => {
        const overlay = document.querySelector<HTMLElement>(
          '[data-state="open"][role="dialog"], [data-state="open"][role="alertdialog"], [data-state="open"][data-radix-popper-content-wrapper]',
        );
        if (overlay) {
          const closeBtn = overlay.querySelector<HTMLElement>("[data-dialog-close], button[aria-label]");
          if (closeBtn) closeBtn.click();
          else document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          return;
        }
        if (canGoBack || window.history.length > 1) {
          router.history.back();
        } else {
          void App.exitApp();
        }
      });
      remove = () => void handle.remove();
    })();

    return () => remove?.();
  }, [router]);

  return null;
}
