import { Link, useLocation } from "@tanstack/react-router";
import { Home, BookOpen, Gamepad2, BarChart3, User } from "lucide-react";

const TABS = [
  { to: "/dashboard", icon: Home, label: "Accueil" },
  { to: "/library", icon: BookOpen, label: "Biblio" },
  { to: "/games", icon: Gamepad2, label: "Jeux" },
  { to: "/stats", icon: BarChart3, label: "Stats" },
  { to: "/profile", icon: User, label: "Profil" },
] as const;

export function BottomNav() {
  const { pathname } = useLocation();
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 border-t border-border/60 bg-background/90 backdrop-blur-md">
      <div className="mx-auto grid max-w-3xl grid-cols-5">
        {TABS.map(({ to, icon: Icon, label }) => {
          const active = pathname === to || pathname.startsWith(to + "/");
          return (
            <Link
              key={to}
              to={to}
              className={`relative flex flex-col items-center justify-center gap-0.5 py-2.5 text-[11px] font-medium transition ${
                active ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {active && (
                <span className="absolute top-0 h-0.5 w-8 rounded-full bg-gradient-to-r from-primary to-fuchsia-500" />
              )}
              <Icon className="h-5 w-5" />
              <span>{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}