import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Medal } from "lucide-react";

type LeaderRow = {
  id: string;
  score: number;
  matiere: string | null;
  full_name: string | null;
  user_id: string;
  created_at: string;
};

export function Leaderboard({ matiereFilter }: { matiereFilter?: string }) {
  const [rows, setRows] = useState<LeaderRow[] | null>(null);

  useEffect(() => {
    (async () => {
      const since = new Date();
      since.setDate(since.getDate() - 7);
      let q = supabase
        .from("leaderboard")
        .select("id, score, matiere, full_name, user_id, created_at")
        .gte("created_at", since.toISOString())
        .order("score", { ascending: false })
        .limit(10);
      if (matiereFilter) q = q.eq("matiere", matiereFilter);
      const { data } = await q;
      setRows((data ?? []) as LeaderRow[]);
    })();
  }, [matiereFilter]);

  const medals = useMemo(() => ["🥇", "🥈", "🥉"], []);

  if (rows === null)
    return (
      <div className="space-y-2">
        {[0, 1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    );
  if (rows.length === 0)
    return (
      <Card>
        <CardContent className="p-8 text-center text-sm text-muted-foreground">
          Aucun score cette semaine. Sois le premier à jouer !
        </CardContent>
      </Card>
    );

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Medal className="h-4 w-4" /> Top 10 des 7 derniers jours{matiereFilter ? ` · ${matiereFilter}` : ""}
      </div>
      {rows.map((r, i) => (
        <Card key={r.id} className={i < 3 ? "border-primary/40 bg-primary/5" : ""}>
          <CardContent className="flex items-center justify-between gap-3 p-4">
            <div className="flex min-w-0 items-center gap-3">
              <div className="w-8 text-center text-lg font-bold">{medals[i] ?? `#${i + 1}`}</div>
              <div className="min-w-0">
                <div className="truncate font-medium">{r.full_name || "Anonyme"}</div>
                <div className="truncate text-xs text-muted-foreground">
                  {r.matiere || "Général"} · {new Date(r.created_at).toLocaleDateString("fr-FR")}
                </div>
              </div>
            </div>
            <div className="shrink-0 text-lg font-bold text-primary">{r.score} pts</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export async function saveScore(params: { score: number; matiere: string; course_id?: string | null }) {
  const { data: userRes } = await supabase.auth.getUser();
  const user = userRes.user;
  if (!user) return;
  const { data: prof } = await supabase.from("profiles").select("full_name").eq("user_id", user.id).maybeSingle();
  await supabase.from("leaderboard").insert({
    user_id: user.id,
    score: params.score,
    matiere: params.matiere,
    course_id: params.course_id ?? null,
    full_name: (prof as any)?.full_name ?? user.email?.split("@")[0] ?? "Anonyme",
  });
}