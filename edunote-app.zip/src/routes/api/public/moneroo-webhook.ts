import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/moneroo-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.MONEROO_SECRET_KEY;
        if (!secret) return new Response("Not configured", { status: 500 });
        let body: any = {};
        try {
          body = await request.json();
        } catch {
          return new Response("Bad payload", { status: 400 });
        }
        const paymentId: string | undefined = body?.data?.id ?? body?.payment?.id ?? body?.id;
        if (!paymentId) return new Response("No payment id", { status: 400 });

        // Contre-vérification via API Moneroo
        const verify = await fetch(`https://api.moneroo.io/v1/payments/${paymentId}/verify`, {
          headers: { Authorization: `Bearer ${secret}`, Accept: "application/json" },
        }).catch(() => null);
        if (!verify || !verify.ok) return new Response("Verify failed", { status: 400 });
        const verified: any = await verify.json();
        const status: string = verified?.data?.status ?? "";
        const isSuccess = status === "success" || status === "SUCCESS" || status === "completed";

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: payment } = await supabaseAdmin
          .from("payments")
          .select("id, user_id")
          .eq("moneroo_payment_id", paymentId)
          .maybeSingle();
        if (!payment) return new Response("Unknown payment", { status: 404 });

        await supabaseAdmin
          .from("payments")
          .update({ status: isSuccess ? "SUCCESS" : "FAILED" })
          .eq("id", payment.id);

        if (isSuccess) {
          await supabaseAdmin.from("profiles").update({ plan: "premium" }).eq("user_id", payment.user_id);
        }

        return new Response("ok");
      },
      GET: async () => new Response("Moneroo webhook ready"),
    },
  },
});