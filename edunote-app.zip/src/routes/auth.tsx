import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { signInWithGoogle } from "@/lib/google-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Loader2, Home, AlertCircle } from "lucide-react";

function translateAuthError(message?: string): string {
  const m = (message ?? "").toLowerCase();
  if (!m) return "Une erreur inconnue est survenue. Réessayez.";
  if (m.includes("invalid login") || m.includes("invalid credentials"))
    return "Email ou mot de passe incorrect.";
  if (m.includes("email not confirmed"))
    return "Votre email n'est pas encore confirmé. Vérifiez votre boîte de réception.";
  if (m.includes("user already registered") || m.includes("already registered"))
    return "Un compte existe déjà avec cet email. Essayez de vous connecter.";
  if (m.includes("password") && m.includes("6"))
    return "Le mot de passe doit contenir au moins 6 caractères.";
  if (m.includes("weak password") || m.includes("pwned"))
    return "Ce mot de passe est trop faible ou compromis. Choisissez-en un plus sécurisé.";
  if (m.includes("rate limit") || m.includes("too many"))
    return "Trop de tentatives. Patientez quelques minutes avant de réessayer.";
  if (m.includes("network") || m.includes("failed to fetch"))
    return "Problème de connexion internet. Vérifiez votre réseau.";
  if (m.includes("unsupported provider") || m.includes("provider is not enabled"))
    return "Ce mode de connexion n'est pas activé. Contactez le support.";
  if (m.includes("invalid email"))
    return "Adresse email invalide.";
  if (m.includes("user not found"))
    return "Aucun compte trouvé avec cet email.";
  return message ?? "Erreur d'authentification.";
}

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Connexion — EduNote" }] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);
  const [refCode, setRefCode] = useState<string>("");
  const [errorMsg, setErrorMsg] = useState<string>("");

  const openDashboardWhenAuthenticated = async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) return false;
    navigate({ to: "/dashboard", replace: true });
    return true;
  };

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: "/dashboard", replace: true });
    });
    const params = new URLSearchParams(window.location.search);
    const ref = (params.get("ref") || "").trim().toUpperCase();
    if (ref) {
      setRefCode(ref);
      setMode("signup");
    }
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg("");
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName, referred_by: refCode || undefined },
            emailRedirectTo: `${window.location.origin}/auth/callback`,
          },
        });
        if (error) throw error;
        if (!data.session) {
          setErrorMsg("Ce compte existe déjà ou attend encore une confirmation. Vérifiez votre boîte mail, puis connectez-vous.");
          toast.info("Vérifiez votre boîte mail avant de vous connecter.");
          setMode("signin");
          return;
        }
        if (!(await openDashboardWhenAuthenticated())) {
          throw new Error("La session n’a pas pu être vérifiée. Réessayez de vous connecter.");
        }
        toast.success("Compte créé ! Vous êtes connecté.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        if (!(await openDashboardWhenAuthenticated())) {
          throw new Error("La session n’a pas pu être vérifiée. Réessayez de vous connecter.");
        }
      }
    } catch (err: any) {
      const friendly = translateAuthError(err?.message);
      setErrorMsg(friendly);
      toast.error(friendly);
    } finally {
      setLoading(false);
    }
  };

  const google = async () => {
    setLoading(true);
    setErrorMsg("");
    try {
      const result = await signInWithGoogle(`${window.location.origin}/auth/callback`);
      if (result.error) {
        const friendly = translateAuthError(result.error.message);
        setErrorMsg(friendly);
        toast.error(friendly);
        setLoading(false);
        return;
      }
      if (!result.redirected) {
        if (!(await openDashboardWhenAuthenticated())) {
          setErrorMsg("La connexion Google n’a pas pu être finalisée. Réessayez.");
          setLoading(false);
        }
      }
    } catch (err: any) {
      const friendly = translateAuthError(err?.message);
      setErrorMsg(friendly);
      toast.error(friendly);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6 py-12">
        <div className="mb-8 text-center">
          <img src="/favicon.png" alt="EduNote" width={40} height={40} className="mx-auto h-10 w-10 rounded-xl" />
          <h1 className="mt-4 text-2xl font-semibold tracking-tight">
            {mode === "signin" ? "Bon retour" : "Créer un compte"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {mode === "signin" ? "Connecte-toi pour continuer à réviser." : "Commence gratuitement en 30 secondes."}
          </p>
        </div>
        <Card>
          <CardContent className="p-6">
            {errorMsg && (
              <div className="mb-4 rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
                <div className="flex items-start gap-2">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium">Échec de la connexion</p>
                    <p className="mt-0.5 text-xs opacity-90">{errorMsg}</p>
                    <Link
                      to="/"
                      className="mt-2 inline-flex items-center gap-1 text-xs font-medium underline"
                    >
                      <Home className="h-3 w-3" /> Retour à l'accueil
                    </Link>
                  </div>
                </div>
              </div>
            )}
            <Button type="button" variant="outline" className="w-full" onClick={google} disabled={loading}>
              Continuer avec Google
            </Button>
            {refCode && mode === "signup" && (
              <div className="mt-3 rounded-md border border-primary/40 bg-primary/5 p-2 text-center text-xs text-primary">
                🎁 Code de parrainage <strong>{refCode}</strong> appliqué : +5 crédits bonus.
              </div>
            )}
            <div className="my-4 flex items-center gap-3 text-xs text-muted-foreground">
              <div className="h-px flex-1 bg-border" /> ou <div className="h-px flex-1 bg-border" />
            </div>
            <form className="space-y-3" onSubmit={submit}>
              {mode === "signup" && (
                <div>
                  <Label htmlFor="name">Nom complet</Label>
                  <Input id="name" value={fullName} onChange={(e) => setFullName(e.target.value)} required placeholder="Awa Diop" className="mt-1" />
                </div>
              )}
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="mt-1" />
              </div>
              <div>
                <Label htmlFor="password">Mot de passe</Label>
                <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={6} required className="mt-1" />
              </div>
              <Button type="submit" disabled={loading} className="w-full">
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                {mode === "signin" ? "Se connecter" : "Créer mon compte"}
              </Button>
            </form>
            <div className="mt-4 text-center text-sm text-muted-foreground">
              {mode === "signin" ? (
                <>Pas encore de compte ? <button type="button" className="text-primary underline" onClick={() => { setMode("signup"); setErrorMsg(""); }}>Inscription</button></>
              ) : (
                <>Déjà inscrit ? <button type="button" className="text-primary underline" onClick={() => { setMode("signin"); setErrorMsg(""); }}>Connexion</button></>
              )}
            </div>
            <div className="mt-4 text-center">
              <Link to="/" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                <Home className="h-3 w-3" /> Retour à l'accueil
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}