import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, AlertCircle, Home } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/auth/callback")({
  ssr: false,
  head: () => ({ meta: [{ title: "Connexion en cours — EduNote" }] }),
  component: AuthCallbackPage,
});

function AuthCallbackPage() {
  const navigate = useNavigate();
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    const finishSignIn = async () => {
      for (let attempt = 0; attempt < 20; attempt += 1) {
        let data;
        let userError;
        try {
          const result = await supabase.auth.getUser();
          data = result.data;
          userError = result.error;
        } catch {
          await new Promise((resolve) => window.setTimeout(resolve, 250));
          continue;
        }
        if (!active) return;
        if (data.user) {
          navigate({ to: "/dashboard", replace: true });
          return;
        }
        if (userError && !/session|jwt|token/i.test(userError.message)) {
          setError("La connexion Google n’a pas pu être finalisée. Réessayez depuis la page de connexion.");
          return;
        }
        await new Promise((resolve) => window.setTimeout(resolve, 250));
      }

      if (active) {
        setError("La session Google n’a pas été reçue. Réessayez depuis la page de connexion.");
      }
    };

    void finishSignIn();
    return () => {
      active = false;
    };
  }, [navigate]);

  return (
    <main className="grid min-h-screen place-items-center bg-background px-6 text-foreground">
      <div className="w-full max-w-sm text-center">
        {error ? (
          <>
            <AlertCircle className="mx-auto h-8 w-8 text-destructive" />
            <h1 className="mt-4 text-xl font-semibold">Connexion incomplète</h1>
            <p className="mt-2 text-sm text-muted-foreground">{error}</p>
            <div className="mt-6 flex flex-col gap-2">
              <Button asChild><Link to="/auth">Réessayer de se connecter</Link></Button>
              <Button asChild variant="outline">
                <Link to="/"><Home className="h-4 w-4" /> Retour à l’accueil</Link>
              </Button>
            </div>
          </>
        ) : (
          <>
            <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
            <h1 className="mt-4 text-xl font-semibold">Connexion en cours</h1>
            <p className="mt-2 text-sm text-muted-foreground">Nous finalisons votre session EduNote…</p>
          </>
        )}
      </div>
    </main>
  );
}