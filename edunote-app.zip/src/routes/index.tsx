import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Sparkles, Layers, MessageCircle, Check, Upload, FileText, Mic, Gift, WifiOff, Coins, Shield, MessageSquare, Gamepad2, Calculator, Languages, Trophy } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

const WHATSAPP_CHANNEL_URL = "https://whatsapp.com/channel/0029VbD4MGs0VycB9SBKuA2s";
const MYCHARIOW_URL = "https://ghosthu.mychariow.co/prd_x5svxjot/checkout";

export const Route = createFileRoute("/")({
  component: Landing,
});

function Landing() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      if (data.session?.user) {
        navigate({ to: "/dashboard", replace: true });
      } else {
        setChecking(false);
      }
    }).catch(() => { if (active) setChecking(false); });
    return () => { active = false; };
  }, [navigate]);

  if (checking) {
    return <div className="min-h-screen bg-background" />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-10 border-b border-border/60 bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link to="/" className="flex items-center gap-2 font-semibold">
            <img src="/favicon.png" alt="EduNote" width={32} height={32} className="h-8 w-8 rounded-lg" />
            EduNote
          </Link>
          <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <a href="#fonctionnalites" className="hover:text-foreground">Fonctionnalités</a>
            <a href="#parrainage" className="hover:text-foreground">Parrainage</a>
            <a href="#tarifs" className="hover:text-foreground">Tarifs</a>
            <a href="#communaute" className="hover:text-foreground">Communauté</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/auth"><Button variant="ghost" size="sm">Se connecter</Button></Link>
            <Link to="/auth"><Button size="sm">Commencer</Button></Link>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-6 pt-16 pb-20 md:pt-24 md:pb-28">
        <div className="mx-auto max-w-3xl text-center">
          <Badge variant="secondary" className="mb-6">Alimenté par l'IA • Mode hors-ligne</Badge>
          <h1 className="text-4xl font-semibold tracking-tight md:text-6xl">
            Transforme tes cours en <span className="text-primary">résumés</span>, flashcards et quiz.
          </h1>
          <p className="mt-6 text-lg text-muted-foreground md:text-xl">
            Importe un PDF, un audio ou une vidéo. EduNote génère automatiquement ta fiche de révision, tes flashcards et tes quiz — en français, en quelques secondes.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/auth"><Button size="lg" className="w-full sm:w-auto">Créer un compte — 10 crédits offerts</Button></Link>
            <a href="#tarifs"><Button size="lg" variant="outline" className="w-full sm:w-auto">Voir les tarifs</Button></a>
          </div>
          <p className="mt-4 text-xs text-muted-foreground">Aucun paiement requis pour commencer. Parraine un ami et gagne 25 crédits.</p>
        </div>
      </section>

      <section id="fonctionnalites" className="mx-auto max-w-6xl px-6 pb-20">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: Sparkles, title: "Résumés intelligents", desc: "Fiches structurées avec points clés, définitions et dates importantes." },
            { icon: Layers, title: "Flashcards", desc: "Cartes réversibles pour mémoriser activement." },
            { icon: BookOpen, title: "Quiz interactifs", desc: "QCM, vrai/faux et questions ouvertes avec explications." },
            { icon: MessageCircle, title: "Chat IA", desc: "Pose des questions sur ton cours et obtiens des réponses fiables." },
            { icon: WifiOff, title: "Mode hors-ligne", desc: "Consulte tes résumés, flashcards et quiz même sans connexion." },
            { icon: Coins, title: "Système de crédits", desc: "10 crédits offerts à l'inscription. 5 crédits = 1 génération (résumé ou quiz)." },
            { icon: Gift, title: "Parrainage récompensé", desc: "Invite un ami : +25 crédits pour toi, +25 crédits pour lui." },
            { icon: Shield, title: "Données sécurisées", desc: "Chaque étudiant n'accède qu'à ses propres cours (RLS activée)." },
            { icon: Gamepad2, title: "Espace Jeux Éducatifs", desc: "Math Dash, Word Master et Chrono-Quiz alimentés par l'IA." },
            { icon: Trophy, title: "Classement hebdo", desc: "Compare tes scores aux autres étudiants dans le leaderboard." },
          ].map((f) => (
            <Card key={f.title} className="border-border/60">
              <CardContent className="p-6">
                <f.icon className="h-6 w-6 text-primary" />
                <h3 className="mt-4 font-semibold">{f.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 grid gap-4 md:grid-cols-3">
          {[
            { icon: FileText, label: "PDF / Word" },
            { icon: Mic, label: "Audio / Vidéo" },
            { icon: Upload, label: "Texte collé" },
          ].map((s) => (
            <div key={s.label} className="flex items-center gap-3 rounded-2xl border border-border/60 p-4">
              <s.icon className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm font-medium">{s.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section id="parrainage" className="mx-auto max-w-5xl px-6 pb-20">
        <Card className="border-primary/40 bg-primary/5">
          <CardContent className="grid gap-6 p-8 md:grid-cols-2 md:items-center">
            <div>
              <Badge variant="secondary" className="mb-3"><Gift className="h-3.5 w-3.5" /> Programme parrainage</Badge>
              <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">Invite tes amis, révisez gratuitement.</h2>
              <p className="mt-3 text-sm text-muted-foreground">
                Partage ton lien unique. Ton ami démarre avec <strong>25 crédits</strong>, et tu reçois <strong>25 crédits</strong> à chaque inscription.
              </p>
              <Link to="/auth" className="mt-5 inline-block"><Button>Récupérer mon lien</Button></Link>
            </div>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Crédits crédités automatiquement</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Historique de tes filleuls</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Aucune limite de parrainage</li>
            </ul>
          </CardContent>
        </Card>
      </section>

      <section id="tarifs" className="mx-auto max-w-5xl px-6 pb-24">
        <div className="text-center">
          <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">Un tarif simple et local</h2>
          <p className="mt-3 text-muted-foreground">Achète ta clé de licence sur MyChariow (Mobile Money & carte) et active Premium en un clic.</p>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          <Card>
            <CardContent className="p-8">
              <h3 className="text-lg font-semibold">Gratuit</h3>
              <p className="mt-1 text-sm text-muted-foreground">Pour découvrir EduNote.</p>
              <div className="mt-6 text-4xl font-semibold">0 XOF</div>
              <ul className="mt-6 space-y-2 text-sm">
                {["10 crédits offerts à l'inscription", "5 crédits = 1 génération", "+25 crédits par parrainage", "Tous les formats d'import", "Mode hors-ligne & jeux inclus"].map((x) => (
                  <li key={x} className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> {x}</li>
                ))}
              </ul>
              <Link to="/auth" className="mt-6 block"><Button variant="outline" className="w-full">Commencer gratuitement</Button></Link>
            </CardContent>
          </Card>
          <Card className="border-primary/40 shadow-lg">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Premium</h3>
                <Badge>Illimité</Badge>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">Pour réviser sans limite.</p>
              <div className="mt-6 text-4xl font-semibold">Clé de licence <span className="text-lg font-normal text-muted-foreground">MyChariow</span></div>
              <ul className="mt-6 space-y-2 text-sm">
                {["Générations illimitées (aucun crédit consommé)", "Chat IA illimité", "Priorité de traitement", "Mode hors-ligne inclus", "Paiement Mobile Money & carte"].map((x) => (
                  <li key={x} className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> {x}</li>
                ))}
              </ul>
              <div className="mt-6 grid gap-2">
                <a href={MYCHARIOW_URL} target="_blank" rel="noopener noreferrer"><Button className="w-full">Acheter une clé sur MyChariow</Button></a>
                <Link to="/auth"><Button variant="outline" className="w-full">J'ai déjà une clé</Button></Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section id="communaute" className="mx-auto max-w-5xl px-6 pb-24">
        <Card className="border-emerald-500/40 bg-emerald-500/5">
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center md:flex-row md:justify-between md:text-left">
            <div className="flex items-start gap-3">
              <MessageSquare className="mt-1 h-6 w-6 text-emerald-600 dark:text-emerald-400" />
              <div>
                <h2 className="text-xl font-semibold tracking-tight">Rejoins la communauté EduNote</h2>
                <p className="mt-1 text-sm text-muted-foreground">Astuces de révision, nouveautés et codes promo directement sur WhatsApp.</p>
              </div>
            </div>
            <a href={WHATSAPP_CHANNEL_URL} target="_blank" rel="noopener noreferrer">
              <Button className="bg-emerald-600 text-white hover:bg-emerald-600/90">
                <MessageSquare className="h-4 w-4" /> Rejoindre la chaîne WhatsApp
              </Button>
            </a>
          </CardContent>
        </Card>
      </section>

      <footer className="border-t border-border/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-6 py-8 text-sm text-muted-foreground md:flex-row">
          <div>© {new Date().getFullYear()} EduNote</div>
          <a href={WHATSAPP_CHANNEL_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 hover:text-foreground">
            <MessageSquare className="h-4 w-4" /> Chaîne WhatsApp
          </a>
          <div>Fait avec ❤️ pour les étudiants francophones</div>
        </div>
      </footer>
    </div>
  );
}
