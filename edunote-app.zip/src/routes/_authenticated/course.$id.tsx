import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { chatWithCourse } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { ArrowLeft, ChevronLeft, ChevronRight, MessageCircle, Printer, RotateCw, Send, Sparkles } from "lucide-react";
import { saveOfflineEntry, useOnlineStatus } from "@/lib/offline";

export const Route = createFileRoute("/_authenticated/course/$id")({
  head: () => ({ meta: [{ title: "Cours — EduNote" }] }),
  component: CoursePage,
});

type Course = { id: string; title: string; subject: string | null; folder: string | null };
type Summary = { content: string; key_points: string[] | null; definitions: any[] | null; key_dates: any[] | null };
type Flashcard = { id: string; question: string; answer: string };
type Quiz = { id: string; type: "qcm" | "vrai_faux" | "ouverte"; question: string; options: string[] | null; correct_answer: string; explanation: string | null };
type Msg = { id?: string; role: "user" | "assistant"; content: string };

function CoursePage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState<Course | null>(null);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(true);
  const [chatOpen, setChatOpen] = useState(false);
  const online = useOnlineStatus();

  useEffect(() => {
    (async () => {
      const { data: c } = await supabase.from("courses").select("id, title, subject, folder").eq("id", id).maybeSingle();
      if (!c) { toast.error("Cours introuvable"); navigate({ to: "/dashboard" }); return; }
      setCourse(c as Course);
      const [{ data: s }, { data: f }, { data: q }] = await Promise.all([
        supabase.from("summaries").select("content, key_points, definitions, key_dates").eq("course_id", id).maybeSingle(),
        supabase.from("flashcards").select("id, question, answer").eq("course_id", id).order("created_at"),
        supabase.from("quizzes").select("id, type, question, options, correct_answer, explanation").eq("course_id", id).order("created_at"),
      ]);
      setSummary(s as Summary | null);
      setFlashcards((f ?? []) as Flashcard[]);
      setQuizzes((q ?? []) as Quiz[]);
      setLoading(false);
      // Sauvegarde locale pour le mode hors-ligne
      saveOfflineEntry({
        courseId: (c as Course).id,
        title: (c as Course).title,
        subject: (c as Course).subject,
        summary: (s as Summary | null)?.content ?? null,
        keyPoints: (s as Summary | null)?.key_points ?? null,
        flashcards: ((f ?? []) as Flashcard[]).map((x) => ({ question: x.question, answer: x.answer })),
        quizzes: ((q ?? []) as Quiz[]).map((x) => ({
          type: x.type,
          question: x.question,
          options: x.options,
          correct_answer: x.correct_answer,
          explanation: x.explanation,
        })),
        savedAt: new Date().toISOString(),
      });
    })();
  }, [id, navigate]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border/60 print:hidden">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link to="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Retour
          </Link>
          <div className="flex items-center gap-2">
            {!online && (
              <Badge variant="secondary" className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300">
                Hors-ligne
              </Badge>
            )}
            <Button variant="outline" size="sm" onClick={() => window.print()}><Printer className="h-4 w-4" /> Imprimer</Button>
            <Button size="sm" onClick={() => setChatOpen((v) => !v)} disabled={!online} title={!online ? "Nécessite Internet" : undefined}>
              <MessageCircle className="h-4 w-4" /> Chat IA
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        {loading || !course ? (
          <div className="space-y-3"><Skeleton className="h-8 w-64" /><Skeleton className="h-64 w-full" /></div>
        ) : (
          <>
            <div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                {course.subject && <Badge variant="secondary">{course.subject}</Badge>}
                {course.folder && <span>• {course.folder}</span>}
              </div>
              <h1 className="mt-2 text-3xl font-semibold tracking-tight">{course.title}</h1>
            </div>

            <Tabs defaultValue="summary" className="mt-6">
              <TabsList>
                <TabsTrigger value="summary">Résumé</TabsTrigger>
                <TabsTrigger value="flashcards">Flashcards ({flashcards.length})</TabsTrigger>
                <TabsTrigger value="quiz">Quiz ({quizzes.length})</TabsTrigger>
              </TabsList>
              <TabsContent value="summary" className="mt-4">
                <SummaryView summary={summary} />
              </TabsContent>
              <TabsContent value="flashcards" className="mt-4">
                <FlashcardsView cards={flashcards} />
              </TabsContent>
              <TabsContent value="quiz" className="mt-4">
                <QuizView quizzes={quizzes} />
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>

      {chatOpen && course && <ChatSidebar courseId={course.id} onClose={() => setChatOpen(false)} />}
    </div>
  );
}

function SummaryView({ summary }: { summary: Summary | null }) {
  if (!summary) return <Card><CardContent className="p-6 text-sm text-muted-foreground">Aucun résumé disponible.</CardContent></Card>;
  return (
    <div className="grid gap-4">
      <Card><CardContent className="p-6">
        <div className="prose prose-sm max-w-none whitespace-pre-wrap text-foreground">{summary.content}</div>
      </CardContent></Card>

      <Accordion type="multiple" className="rounded-2xl border border-border bg-card px-4">
        {summary.key_points && summary.key_points.length > 0 && (
          <AccordionItem value="points">
            <AccordionTrigger>Points clés</AccordionTrigger>
            <AccordionContent>
              <ul className="list-disc space-y-1 pl-5 text-sm">
                {summary.key_points.map((p, i) => <li key={i}>{p}</li>)}
              </ul>
            </AccordionContent>
          </AccordionItem>
        )}
        {summary.definitions && summary.definitions.length > 0 && (
          <AccordionItem value="defs">
            <AccordionTrigger>Définitions</AccordionTrigger>
            <AccordionContent>
              <dl className="space-y-2 text-sm">
                {summary.definitions.map((d: any, i: number) => (
                  <div key={i}><dt className="font-medium">{d.term}</dt><dd className="text-muted-foreground">{d.definition}</dd></div>
                ))}
              </dl>
            </AccordionContent>
          </AccordionItem>
        )}
        {summary.key_dates && summary.key_dates.length > 0 && (
          <AccordionItem value="dates">
            <AccordionTrigger>Dates importantes</AccordionTrigger>
            <AccordionContent>
              <ul className="space-y-1 text-sm">
                {summary.key_dates.map((d: any, i: number) => (
                  <li key={i}><span className="font-medium">{d.date}</span> — {d.event}</li>
                ))}
              </ul>
            </AccordionContent>
          </AccordionItem>
        )}
      </Accordion>
    </div>
  );
}

function FlashcardsView({ cards }: { cards: Flashcard[] }) {
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  if (cards.length === 0) return <Card><CardContent className="p-6 text-sm text-muted-foreground">Aucune flashcard.</CardContent></Card>;
  const card = cards[i];
  const go = (d: number) => { setFlipped(false); setI((v) => (v + d + cards.length) % cards.length); };
  return (
    <div className="mx-auto max-w-xl">
      <div className="text-center text-xs text-muted-foreground">{i + 1} / {cards.length}</div>
      <div className="mt-3 [perspective:1000px]">
        <button
          onClick={() => setFlipped((v) => !v)}
          className="relative block h-64 w-full [transform-style:preserve-3d] transition-transform duration-500"
          style={{ transform: flipped ? "rotateY(180deg)" : "none" }}
        >
          <Card className="absolute inset-0 [backface-visibility:hidden]">
            <CardContent className="grid h-full place-items-center p-6 text-center text-lg font-medium">{card.question}</CardContent>
          </Card>
          <Card className="absolute inset-0 [transform:rotateY(180deg)] [backface-visibility:hidden] border-primary/40">
            <CardContent className="grid h-full place-items-center p-6 text-center text-base">{card.answer}</CardContent>
          </Card>
        </button>
      </div>
      <div className="mt-4 flex items-center justify-between gap-2">
        <Button variant="outline" onClick={() => go(-1)}><ChevronLeft className="h-4 w-4" /></Button>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => go(1)}><RotateCw className="h-4 w-4" /> À revoir</Button>
          <Button onClick={() => go(1)}>Je sais</Button>
        </div>
        <Button variant="outline" onClick={() => go(1)}><ChevronRight className="h-4 w-4" /></Button>
      </div>
    </div>
  );
}

function QuizView({ quizzes }: { quizzes: Quiz[] }) {
  const [i, setI] = useState(0);
  const [answer, setAnswer] = useState<string>("");
  const [checked, setChecked] = useState(false);
  const [score, setScore] = useState(0);
  if (quizzes.length === 0) return <Card><CardContent className="p-6 text-sm text-muted-foreground">Aucun quiz.</CardContent></Card>;
  const q = quizzes[i];
  const correct = normalize(answer) === normalize(q.correct_answer);
  const next = () => {
    if (checked && correct) setScore((s) => s + 1);
    setChecked(false); setAnswer("");
    setI((v) => Math.min(v + 1, quizzes.length - 1));
  };
  const done = i === quizzes.length - 1 && checked;
  return (
    <Card><CardContent className="p-6">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Question {i + 1} / {quizzes.length}</span>
        <span>Score: {score}</span>
      </div>
      <div className="mt-3 text-base font-medium">{q.question}</div>

      <div className="mt-4 space-y-2">
        {q.type === "qcm" && (q.options ?? []).map((opt) => (
          <label key={opt} className={`flex cursor-pointer items-center gap-2 rounded-lg border p-3 text-sm ${answer === opt ? "border-primary bg-primary/5" : "border-border"}`}>
            <input type="radio" name="opt" checked={answer === opt} onChange={() => setAnswer(opt)} />
            {opt}
          </label>
        ))}
        {q.type === "vrai_faux" && ["Vrai", "Faux"].map((opt) => (
          <label key={opt} className={`flex cursor-pointer items-center gap-2 rounded-lg border p-3 text-sm ${answer === opt ? "border-primary bg-primary/5" : "border-border"}`}>
            <input type="radio" name="opt" checked={answer === opt} onChange={() => setAnswer(opt)} />
            {opt}
          </label>
        ))}
        {q.type === "ouverte" && (
          <input className="w-full rounded-lg border border-border bg-background p-3 text-sm" value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="Ta réponse…" />
        )}
      </div>

      {checked && (
        <div className={`mt-4 rounded-lg border p-3 text-sm ${correct ? "border-green-500/50 bg-green-500/10" : "border-destructive/50 bg-destructive/10"}`}>
          <div className="font-medium">{correct ? "Bonne réponse !" : `Réponse attendue : ${q.correct_answer}`}</div>
          {q.explanation && <div className="mt-1 text-muted-foreground">{q.explanation}</div>}
        </div>
      )}

      <div className="mt-4 flex justify-end gap-2">
        {!checked ? (
          <Button onClick={() => setChecked(true)} disabled={!answer.trim()}>Valider</Button>
        ) : done ? (
          <Button onClick={() => { setI(0); setScore(0); setChecked(false); setAnswer(""); }}>Recommencer</Button>
        ) : (
          <Button onClick={next}>Suivant</Button>
        )}
      </div>
    </CardContent></Card>
  );
}

function normalize(s: string) { return (s ?? "").trim().toLowerCase(); }

function ChatSidebar({ courseId, onClose }: { courseId: string; onClose: () => void }) {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const chat = useServerFn(chatWithCourse);
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.from("chat_messages").select("role, content").eq("course_id", courseId).order("created_at").then(({ data }) => {
      setMessages(((data ?? []) as any[]).map((m) => ({ role: m.role, content: m.content })));
    });
  }, [courseId]);

  useEffect(() => { bottom.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async (text: string) => {
    if (!text.trim() || sending) return;
    setSending(true);
    setMessages((m) => [...m, { role: "user", content: text }]);
    setInput("");
    try {
      const { answer } = await chat({ data: { courseId, message: text } });
      setMessages((m) => [...m, { role: "assistant", content: answer }]);
    } catch (e: any) {
      const msg = e?.message ?? "Échec du chat";
      if (/quota/i.test(msg)) {
        toast.error(msg, {
          description: "Passe au Premium pour continuer sans limite.",
          action: { label: "Passer au Premium", onClick: () => navigate({ to: "/dashboard" }) },
        });
      } else {
        toast.error(msg);
      }
      setMessages((m) => m.slice(0, -1));
    } finally {
      setSending(false);
    }
  };

  const suggestions = ["Simplifie", "Donne un exemple", "Interroge-moi"];

  return (
    <div className="fixed inset-0 z-40 flex justify-end print:hidden" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <aside className="relative flex h-full w-full max-w-md flex-col border-l border-border bg-background" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-border p-4">
          <div className="flex items-center gap-2 font-medium"><Sparkles className="h-4 w-4 text-primary" /> Chat IA</div>
          <Button variant="ghost" size="sm" onClick={onClose}>Fermer</Button>
        </div>
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {messages.length === 0 && <div className="text-sm text-muted-foreground">Pose une question sur ce cours.</div>}
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>{m.content}</div>
            </div>
          ))}
          <div ref={bottom} />
        </div>
        <div className="border-t border-border p-3">
          <div className="mb-2 flex flex-wrap gap-2">
            {suggestions.map((s) => (
              <button key={s} onClick={() => send(s)} className="rounded-full border border-border px-3 py-1 text-xs hover:bg-accent" disabled={sending}>{s}</button>
            ))}
          </div>
          <form className="flex items-center gap-2" onSubmit={(e) => { e.preventDefault(); send(input); }}>
            <input className="flex-1 rounded-lg border border-border bg-background px-3 py-2 text-sm" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Écris ta question…" disabled={sending} />
            <Button type="submit" size="sm" disabled={sending}><Send className="h-4 w-4" /></Button>
          </form>
        </div>
      </aside>
    </div>
  );
}