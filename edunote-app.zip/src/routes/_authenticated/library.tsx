import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Search, FolderOpen } from "lucide-react";
import { readOfflineHistory, useOnlineStatus, type OfflineEntry } from "@/lib/offline";

export const Route = createFileRoute("/_authenticated/library")({
  head: () => ({ meta: [{ title: "Ma bibliothèque — EduNote" }] }),
  component: LibraryPage,
});

type Course = { id: string; title: string; subject: string | null; folder: string | null; source_type: string; created_at: string };

function LibraryPage() {
  const [courses, setCourses] = useState<Course[] | null>(null);
  const [q, setQ] = useState("");
  const online = useOnlineStatus();
  const [offlineEntries, setOfflineEntries] = useState<OfflineEntry[]>([]);

  useEffect(() => {
    if (!online) { setOfflineEntries(readOfflineHistory()); return; }
    supabase.from("courses")
      .select("id, title, subject, folder, source_type, created_at")
      .order("created_at", { ascending: false })
      .then(({ data }) => setCourses((data ?? []) as Course[]));
  }, [online]);

  const filtered = (courses ?? []).filter(c =>
    !q || c.title.toLowerCase().includes(q.toLowerCase()) || (c.subject ?? "").toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 via-background to-background text-foreground">
      <header className="mx-auto max-w-3xl px-4 pt-6 sm:px-6 sm:pt-8">
        <h1 className="text-2xl font-bold tracking-tight">Ma bibliothèque 📚</h1>
        <p className="text-sm text-muted-foreground">Tous tes cours, fiches et quiz générés.</p>
      </header>

      <main className="mx-auto max-w-3xl space-y-5 px-4 py-5 sm:px-6">
        {online && (
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Rechercher un cours…"
              className="rounded-2xl pl-9"
            />
          </div>
        )}

        {!online ? (
          offlineEntries.length === 0 ? (
            <EmptyState text="Aucune révision hors-ligne enregistrée." />
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {offlineEntries.map((e) => (
                <Link key={e.courseId} to="/course/$id" params={{ id: e.courseId }}>
                  <Card className="rounded-2xl transition hover:border-primary/50">
                    <CardContent className="p-5">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <BookOpen className="h-3.5 w-3.5" /> {e.subject || "Sans matière"}
                      </div>
                      <div className="mt-2 line-clamp-2 font-medium">{e.title}</div>
                      <div className="mt-2 line-clamp-2 text-xs text-muted-foreground">
                        {e.summary?.slice(0, 140) || "Résumé indisponible"}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )
        ) : courses === null ? (
          <div className="grid gap-3 sm:grid-cols-2">
            {[0,1,2,3].map(i => <Skeleton key={i} className="h-28 rounded-2xl" />)}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState text="Aucun cours pour le moment. Ajoute-en un depuis l'accueil." />
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {filtered.map((c) => (
              <Link key={c.id} to="/course/$id" params={{ id: c.id }}>
                <Card className="rounded-2xl transition hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-md">
                  <CardContent className="p-5">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <FolderOpen className="h-3.5 w-3.5" /> {c.subject || "Sans matière"} {c.folder ? `• ${c.folder}` : ""}
                    </div>
                    <div className="mt-2 line-clamp-2 font-medium">{c.title}</div>
                    <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                      <Badge variant="secondary" className="capitalize">{c.source_type}</Badge>
                      <span>{new Date(c.created_at).toLocaleDateString("fr-FR")}</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <Card className="rounded-2xl">
      <CardContent className="p-8 text-center text-sm text-muted-foreground">{text}</CardContent>
    </Card>
  );
}