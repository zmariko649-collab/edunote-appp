import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { generateGameQuestions } from "@/lib/games.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { ArrowLeft, Calculator, Flame, Play, RotateCw, Trophy, Delete, Loader2 } from "lucide-react";
import { saveScore } from "@/components/leaderboard";

export const Route = createFileRoute("/_authenticated/games/math")({
  head: () => ({ meta: [{ title: "Math Dash — EduNote" }] }),
  component: MathDash,
});

type Level = "facile" | "moyen" | "difficile";
type Challenge = { prompt: string; answer: number };

const TOTAL_QUESTIONS = 15;
const COMBO_THRESHOLD = 5;

function rand(a: number, b: number) { return Math.floor(Math.random() * (b - a + 1)) + a; }

function generate(level: Level): Challenge {
  const kinds = level === "facile"
    ? ["add", "sub", "mul"]
    : level === "moyen"
      ? ["add", "sub", "mul", "div", "priority", "equation"]
      : ["mul", "div", "priority", "equation", "fraction"];
  const kind = kinds[rand(0, kinds.length - 1)];
  const max = level === "facile" ? 20 : level === "moyen" ? 50 : 99;

  if (kind === "add") { const a = rand(2, max), b = rand(2, max); return { prompt: `${a} + ${b}`, answer: a + b }; }
  if (kind === "sub") { const a = rand(10, max), b = rand(2, a); return { prompt: `${a} − ${b}`, answer: a - b }; }
  if (kind === "mul") { const a = rand(2, level === "difficile" ? 15 : 12), b = rand(2, 12); return { prompt: `${a} × ${b}`, answer: a * b }; }
  if (kind === "div") { const b = rand(2, 12), r = rand(2, 12), a = b * r; return { prompt: `${a} ÷ ${b}`, answer: r }; }
  if (kind === "priority") {
    const a = rand(2, 12), b = rand(2, 12), c = rand(2, 20);
    return { prompt: `${c} + ${a} × ${b}`, answer: c + a * b };
  }
  if (kind === "equation") {
    // ax + b = c  → find x integer
    const x = rand(2, 15), a = rand(2, 9), b = rand(1, 20);
    const c = a * x + b;
    return { prompt: `${a}x + ${b} = ${c}   →  x = ?`, answer: x };
  }
  if (kind === "fraction") {
    // simple: (a/b) of n where b | n
    const b = rand(2, 6), n = b * rand(2, 12), a = rand(1, b - 1);
    return { prompt: `${a}/${b} de ${n}`, answer: (a * n) / b };
  }
  return { prompt: "1 + 1", answer: 2 };
}

function MathDash() {
  const [phase, setPhase] = useState<"select" | "playing" | "finished">("select");
  const [level, setLevel] = useState<Level>("moyen");
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [input, setInput] = useState("");
  const [feedback, setFeedback] = useState<null | "ok" | "ko">(null);
  const [saved, setSaved] = useState(false);
  const [flash, setFlash] = useState(false);
  const [loading, setLoading] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const genQuestions = useServerFn(generateGameQuestions);

  useEffect(() => () => { if (timeoutRef.current) clearTimeout(timeoutRef.current); }, []);

  const start = async () => {
    setLoading(true);
    let list: Challenge[] = [];
    try {
      const res = await genQuestions({ data: { game: "math", level, count: TOTAL_QUESTIONS } });
      list = (res?.questions ?? [])
        .filter((q: any) => q && typeof q.prompt === "string" && Number.isFinite(Number(q.answer)))
        .map((q: any) => ({ prompt: q.prompt as string, answer: Number(q.answer) }))
        .slice(0, TOTAL_QUESTIONS);
    } catch {
      toast.message("Défis hors-ligne", { description: "IA indisponible, génération locale." });
    }
    if (list.length < 5) {
      list = [];
      for (let i = 0; i < TOTAL_QUESTIONS; i++) list.push(generate(level));
    }
    setLoading(false);
    setChallenges(list);
    setIdx(0);
    setScore(0);
    setCombo(0);
    setInput("");
    setFeedback(null);
    setSaved(false);
    setPhase("playing");
  };

  const current = challenges[idx];
  const doubled = combo >= COMBO_THRESHOLD;
  const progressPct = ((idx + 1) / challenges.length) * 100;

  const submit = () => {
    if (feedback) return;
    if (input.trim() === "") return;
    const parsed = Number(input.replace(",", "."));
    if (Number.isNaN(parsed)) return;
    const ok = Math.abs(parsed - current.answer) < 1e-6;
    if (ok) {
      const base = level === "facile" ? 50 : level === "moyen" ? 100 : 150;
      const newCombo = combo + 1;
      const willBeDoubled = newCombo >= COMBO_THRESHOLD;
      const gained = willBeDoubled ? base * 2 : base;
      setScore((s) => s + gained);
      setCombo(newCombo);
      setFeedback("ok");
      if (willBeDoubled) { setFlash(true); setTimeout(() => setFlash(false), 400); }
    } else {
      setFeedback("ko");
      setCombo(0);
    }
    timeoutRef.current = setTimeout(() => nextQuestion(), 700);
  };

  const nextQuestion = () => {
    if (idx + 1 >= challenges.length) { finish(); return; }
    setIdx((i) => i + 1);
    setInput("");
    setFeedback(null);
  };

  const finish = async () => {
    setPhase("finished");
    if (saved) return;
    try {
      await saveScore({ score, matiere: "Mathématiques" });
      setSaved(true);
    } catch (e: any) {
      toast.error(e?.message ?? "Erreur d'enregistrement du score");
    }
  };

  const type = (v: string) => {
    if (feedback) return;
    if (v === "back") return setInput((i) => i.slice(0, -1));
    if (v === "clear") return setInput("");
    if (v === "enter") return submit();
    if (v === "-" && input.length === 0) return setInput("-");
    setInput((i) => (i + v).slice(0, 8));
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (phase !== "playing") return;
      if (/^[0-9]$/.test(e.key)) type(e.key);
      else if (e.key === "Backspace") type("back");
      else if (e.key === "Enter") type("enter");
      else if (e.key === "-" || e.key === "." || e.key === ",") type(e.key === "," ? "." : e.key);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, input, feedback]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-emerald-500/5 text-foreground">
      <header className="border-b border-border/60 bg-background/70 backdrop-blur">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-4 py-3 sm:px-6 sm:py-4">
          <Link to="/games" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Jeux
          </Link>
          <div className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-emerald-500" />
            <span className="font-semibold">Math Dash</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 py-6 sm:px-6 sm:py-10">
        {phase === "select" && (
          <Card className="border-emerald-500/30">
            <CardContent className="space-y-5 p-6">
              <div>
                <h1 className="text-xl font-bold">Choisis ton niveau</h1>
                <p className="text-sm text-muted-foreground">Enchaîne 5 bonnes réponses pour activer le <b>Combo x2</b> !</p>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {(["facile", "moyen", "difficile"] as Level[]).map((l) => (
                  <Button
                    key={l}
                    variant={level === l ? "default" : "outline"}
                    onClick={() => setLevel(l)}
                    className="capitalize"
                  >
                    {l}
                  </Button>
                ))}
              </div>
              <Button onClick={start} disabled={loading} className="w-full bg-emerald-600 hover:bg-emerald-700">
                {loading
                  ? <><Loader2 className="mr-1 h-4 w-4 animate-spin" /> Génération IA…</>
                  : <><Play className="mr-1 h-4 w-4" /> Démarrer ({TOTAL_QUESTIONS} défis)</>}
              </Button>
            </CardContent>
          </Card>
        )}

        {phase === "playing" && current && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Défi {idx + 1} / {challenges.length}</span>
              <span className="font-semibold">{score} pts</span>
            </div>
            <Progress value={progressPct} className="h-1.5" />

            <div className={`relative overflow-hidden rounded-2xl border p-6 text-center transition ${
              doubled ? "border-amber-500/60 bg-gradient-to-br from-amber-500/10 to-orange-500/10" : "border-border/60 bg-card"
            } ${flash ? "animate-pulse" : ""}`}>
              {doubled && (
                <div className="mb-2 inline-flex items-center gap-1 rounded-full bg-amber-500/20 px-3 py-1 text-xs font-bold text-amber-600 dark:text-amber-400">
                  <Flame className="h-3.5 w-3.5" /> COMBO x{combo} — Points x2
                </div>
              )}
              <div className="text-4xl font-bold tracking-wider sm:text-5xl">{current.prompt}</div>
              <div className={`mx-auto mt-4 min-h-[3rem] w-full max-w-xs rounded-xl border-2 px-4 py-3 text-3xl font-mono font-bold transition ${
                feedback === "ok" ? "border-emerald-500 bg-emerald-500/10 text-emerald-600"
                  : feedback === "ko" ? "border-red-500 bg-red-500/10 text-red-600"
                  : "border-border bg-background"
              }`}>
                {input || <span className="text-muted-foreground/40">—</span>}
              </div>
              {feedback === "ko" && (
                <div className="mt-2 text-sm text-red-500">Réponse : <b>{current.answer}</b></div>
              )}
            </div>

            <Keypad onKey={type} />

            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Série : {combo} / {COMBO_THRESHOLD}</span>
              <span>Niveau : {level}</span>
            </div>
          </div>
        )}

        {phase === "finished" && (
          <Card className="border-emerald-500/40 bg-gradient-to-br from-emerald-500/5 to-cyan-500/5">
            <CardContent className="space-y-5 p-8 text-center">
              <Trophy className="mx-auto h-14 w-14 text-amber-500 animate-bounce" />
              <div>
                <div className="text-sm text-muted-foreground">Partie terminée</div>
                <div className="mt-1 text-5xl font-black tracking-tight">{score}</div>
                <div className="mt-1 text-sm text-muted-foreground">points · niveau {level}</div>
              </div>
              {saved && <Badge variant="secondary" className="mx-auto">Score enregistré au classement</Badge>}
              <div className="flex flex-wrap justify-center gap-2">
                <Button onClick={start} variant="outline"><RotateCw className="mr-1 h-4 w-4" /> Rejouer</Button>
                <Link to="/games"><Button>Autres jeux</Button></Link>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}

function Keypad({ onKey }: { onKey: (v: string) => void }) {
  const keys = ["7", "8", "9", "4", "5", "6", "1", "2", "3"];
  return (
    <div className="mx-auto grid max-w-xs grid-cols-3 gap-2">
      {keys.map((k) => (
        <Button key={k} variant="outline" className="h-14 text-xl font-semibold" onClick={() => onKey(k)}>{k}</Button>
      ))}
      <Button variant="outline" className="h-14 text-xl font-semibold" onClick={() => onKey("-")}>−</Button>
      <Button variant="outline" className="h-14 text-xl font-semibold" onClick={() => onKey("0")}>0</Button>
      <Button variant="outline" className="h-14" onClick={() => onKey("back")} aria-label="Effacer"><Delete className="h-5 w-5" /></Button>
      <Button className="col-span-3 h-14 bg-emerald-600 text-base font-semibold hover:bg-emerald-700" onClick={() => onKey("enter")}>
        Valider
      </Button>
    </div>
  );
}