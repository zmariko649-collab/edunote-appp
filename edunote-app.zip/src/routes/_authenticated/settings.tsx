import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { redeemLicenseKey } from "@/lib/license.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ArrowLeft, KeyRound, Sparkles, ExternalLink } from "lucide-react";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Paramètres — EduNote" }] }),
  component: SettingsPage,
});

const BUY_URL = "https://ghosthu.mychariow.co/prd_x5svxjot/checkout";

function SettingsPage() {
  const redeem = useServerFn(redeemLicenseKey);
  const [plan, setPlan] = useState<string>("free");
  const [email, setEmail] = useState<string>("");
  const [key, setKey] = useState("");
  const [loading, setLoading] = useState(false);

  const loadProfile = async () => {
    const { data: u } = await supabase.auth.getUser();
    const uid = u.user?.id;
    setEmail(u.user?.email ?? "");
    if (!uid) return;
    const { data: p } = await supabase
      .from("profiles")
      .select("plan")
      .eq("user_id", uid)
      .maybeSingle();
    if (p?.plan) setPlan(p.plan);
  };

  useEffect(() => { loadProfile(); }, []);

  const isPremium = plan === "premium";

  const activate = async () => {
    const trimmed = key.trim().toUpperCase();
    if (!trimmed) { toast.error("Entrez une clé de licence."); return; }
    setLoading(true);
    try {
      await redeem({ data: { key: trimmed } });
      toast.success("Accès Premium activé 🎉");
      setKey("");
      await loadProfile();
    } catch (e: any) {
      toast.error(e?.message ?? "Clé invalide ou déjà utilisée");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border/60">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-6 py-4">
          <Link to="/dashboard" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Retour
          </Link>
          <span className="font-semibold">Paramètres</span>
          <span className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-6 px-6 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Profil</CardTitle>
            <CardDescription>{email || "—"}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Forfait actuel :</span>
              <Badge variant={isPremium ? "default" : "secondary"}>
                {isPremium ? "Premium (illimité)" : "Gratuit"}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <KeyRound className="h-5 w-5 text-primary" /> Clé de licence
            </CardTitle>
            <CardDescription>
              {isPremium
                ? "Votre compte est déjà Premium. Aucune action nécessaire."
                : "Collez votre clé EDUNOTE-XXXX-XXXX pour débloquer l'accès illimité."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!isPremium && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="licence-key">Entrez votre clé de licence</Label>
                  <Input
                    id="licence-key"
                    placeholder="EDUNOTE-XXXX-XXXX"
                    value={key}
                    onChange={(e) => setKey(e.target.value)}
                    autoComplete="off"
                    spellCheck={false}
                    className="font-mono uppercase"
                    onKeyDown={(e) => { if (e.key === "Enter") activate(); }}
                  />
                </div>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <Button onClick={activate} disabled={loading} className="gap-2">
                    <Sparkles className="h-4 w-4" />
                    {loading ? "Vérification…" : "Activer mon accès Premium"}
                  </Button>
                  <a href={BUY_URL} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" className="w-full gap-2 sm:w-auto">
                      <ExternalLink className="h-4 w-4" /> Acheter une clé
                    </Button>
                  </a>
                </div>
                <p className="text-xs text-muted-foreground">
                  Chaque clé n'est utilisable qu'une seule fois et débloque un accès Premium illimité.
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}