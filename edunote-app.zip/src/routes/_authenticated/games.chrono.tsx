import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { generateGameQuestions } from "@/lib/games.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { ArrowLeft, Timer, Trophy, Play, RotateCw, Sparkles, BookOpen, Globe2, Landmark, FlaskConical, Languages, Calculator, Loader2 } from "lucide-react";
import { saveScore } from "@/components/leaderboard";

export const Route = createFileRoute("/_authenticated/games/chrono")({
  head: () => ({ meta: [{ title: "Chrono-Quiz — EduNote" }] }),
  component: ChronoPage,
});

const QUESTION_TIME = 15;
const TOTAL_QUESTIONS = 10;

type Q = { q: string; options: string[]; answer: string };
type Subject = { key: string; label: string; icon: any; color: string; bank: Q[] };

const SUBJECTS: Subject[] = [
  {
    key: "Culture générale", label: "Culture générale", icon: Sparkles, color: "text-primary",
    bank: [
      { q: "Quelle est la capitale de l'Australie ?", options: ["Sydney", "Canberra", "Melbourne", "Perth"], answer: "Canberra" },
      { q: "Qui a peint la Joconde ?", options: ["Van Gogh", "Léonard de Vinci", "Picasso", "Monet"], answer: "Léonard de Vinci" },
      { q: "Combien de continents y a-t-il ?", options: ["5", "6", "7", "8"], answer: "7" },
      { q: "Quel est l'océan le plus vaste ?", options: ["Atlantique", "Indien", "Arctique", "Pacifique"], answer: "Pacifique" },
      { q: "Quelle est la monnaie du Japon ?", options: ["Yuan", "Won", "Yen", "Baht"], answer: "Yen" },
      { q: "Qui a écrit 'Les Misérables' ?", options: ["Zola", "Hugo", "Balzac", "Flaubert"], answer: "Hugo" },
      { q: "Combien de joueurs dans une équipe de foot ?", options: ["9", "10", "11", "12"], answer: "11" },
      { q: "Quelle planète est la plus proche du Soleil ?", options: ["Vénus", "Mars", "Mercure", "Terre"], answer: "Mercure" },
      { q: "En quelle année a eu lieu la Révolution française ?", options: ["1689", "1789", "1804", "1848"], answer: "1789" },
      { q: "Quel est le plus long fleuve du monde ?", options: ["Nil", "Amazone", "Yangzi", "Mississippi"], answer: "Amazone" },
      { q: "Quel gaz les plantes absorbent-elles ?", options: ["O₂", "CO₂", "N₂", "H₂"], answer: "CO₂" },
      { q: "Combien de côtés a un hexagone ?", options: ["5", "6", "7", "8"], answer: "6" },
    ],
  },
  {
    key: "Histoire", label: "Histoire", icon: Landmark, color: "text-amber-500",
    bank: [
      { q: "Année de la chute du mur de Berlin ?", options: ["1985", "1989", "1991", "1993"], answer: "1989" },
      { q: "Qui était le premier empereur romain ?", options: ["Jules César", "Auguste", "Néron", "Trajan"], answer: "Auguste" },
      { q: "En quelle année a commencé la 1ʳᵉ Guerre mondiale ?", options: ["1912", "1914", "1918", "1920"], answer: "1914" },
      { q: "Qui a découvert l'Amérique en 1492 ?", options: ["Magellan", "Vasco de Gama", "Colomb", "Cortés"], answer: "Colomb" },
      { q: "Napoléon a été vaincu à…", options: ["Austerlitz", "Waterloo", "Iéna", "Trafalgar"], answer: "Waterloo" },
      { q: "Prise de la Bastille : quel jour ?", options: ["4 août", "14 juillet", "10 août", "1 mai"], answer: "14 juillet" },
      { q: "Qui a inventé l'imprimerie moderne ?", options: ["Gutenberg", "Newton", "Edison", "Franklin"], answer: "Gutenberg" },
      { q: "L'Empire byzantin s'est effondré en…", options: ["1204", "1453", "1492", "1517"], answer: "1453" },
      { q: "Auteur de la Déclaration des Droits de l'Homme (1789) ?", options: ["La Fayette", "Robespierre", "Mirabeau", "Danton"], answer: "La Fayette" },
      { q: "Guerre froide opposait principalement…", options: ["FR / DE", "USA / URSS", "UK / Chine", "USA / Cuba"], answer: "USA / URSS" },
      { q: "Qui régnait en France en 1715 ?", options: ["Louis XIII", "Louis XIV", "Louis XV", "Louis XVI"], answer: "Louis XIV" },
      { q: "Fin de la 2ᵉ Guerre mondiale en Europe ?", options: ["1943", "1944", "1945", "1946"], answer: "1945" },
    ],
  },
  {
    key: "Géographie", label: "Géographie", icon: Globe2, color: "text-cyan-500",
    bank: [
      { q: "Capitale du Canada ?", options: ["Toronto", "Ottawa", "Montréal", "Vancouver"], answer: "Ottawa" },
      { q: "Plus haute montagne du monde ?", options: ["K2", "Mont Blanc", "Everest", "Kilimandjaro"], answer: "Everest" },
      { q: "Pays traversé par l'Amazone ?", options: ["Argentine", "Brésil", "Chili", "Pérou"], answer: "Brésil" },
      { q: "Le Sahara est un…", options: ["Océan", "Désert", "Plateau", "Fleuve"], answer: "Désert" },
      { q: "Capitale de l'Égypte ?", options: ["Alexandrie", "Le Caire", "Louxor", "Assouan"], answer: "Le Caire" },
      { q: "Île la plus peuplée du monde ?", options: ["Honshu", "Java", "Grande-Bretagne", "Cuba"], answer: "Java" },
      { q: "Détroit entre Europe et Afrique ?", options: ["Bosphore", "Gibraltar", "Bering", "Malacca"], answer: "Gibraltar" },
      { q: "Combien d'États aux USA ?", options: ["48", "50", "51", "52"], answer: "50" },
      { q: "Fleuve traversant Paris ?", options: ["Loire", "Rhône", "Seine", "Garonne"], answer: "Seine" },
      { q: "Continent le moins peuplé ?", options: ["Océanie", "Antarctique", "Amérique du Sud", "Europe"], answer: "Antarctique" },
      { q: "Capitale de l'Allemagne ?", options: ["Munich", "Hambourg", "Berlin", "Francfort"], answer: "Berlin" },
      { q: "Mer bordant la Côte d'Azur ?", options: ["Adriatique", "Méditerranée", "Baltique", "Noire"], answer: "Méditerranée" },
    ],
  },
  {
    key: "Sciences", label: "Sciences", icon: FlaskConical, color: "text-emerald-500",
    bank: [
      { q: "Formule chimique de l'eau ?", options: ["H₂O", "CO₂", "O₂", "NaCl"], answer: "H₂O" },
      { q: "Vitesse de la lumière (km/s) ?", options: ["3 000", "30 000", "300 000", "3 000 000"], answer: "300 000" },
      { q: "Organe qui pompe le sang ?", options: ["Foie", "Cœur", "Rein", "Poumon"], answer: "Cœur" },
      { q: "Combien d'os dans le corps humain ?", options: ["156", "206", "256", "306"], answer: "206" },
      { q: "Élément de symbole 'Au' ?", options: ["Argent", "Or", "Aluminium", "Cuivre"], answer: "Or" },
      { q: "L'ADN se trouve dans…", options: ["Le cytoplasme", "Le noyau", "La membrane", "Les ribosomes"], answer: "Le noyau" },
      { q: "Force qui attire les objets vers la Terre ?", options: ["Magnétisme", "Gravité", "Friction", "Inertie"], answer: "Gravité" },
      { q: "L'unité de courant électrique ?", options: ["Volt", "Ohm", "Ampère", "Watt"], answer: "Ampère" },
      { q: "Pluton est classé comme…", options: ["Planète", "Étoile", "Planète naine", "Astéroïde"], answer: "Planète naine" },
      { q: "Quel gaz respirons-nous ?", options: ["CO₂", "N₂", "O₂", "H₂"], answer: "O₂" },
      { q: "Qui a formulé E = mc² ?", options: ["Newton", "Einstein", "Bohr", "Hawking"], answer: "Einstein" },
      { q: "Nombre de chromosomes humains ?", options: ["23", "44", "46", "48"], answer: "46" },
    ],
  },
  {
    key: "Français", label: "Français", icon: BookOpen, color: "text-rose-500",
    bank: [
      { q: "Le pluriel de 'cheval' ?", options: ["chevals", "chevaux", "chevales", "chevals"], answer: "chevaux" },
      { q: "'Ils … arrivés hier.' (auxiliaire correct)", options: ["ont", "sont", "ont été", "avaient"], answer: "sont" },
      { q: "Synonyme de 'joyeux' ?", options: ["triste", "content", "fatigué", "calme"], answer: "content" },
      { q: "Antonyme de 'facile' ?", options: ["simple", "aisé", "difficile", "clair"], answer: "difficile" },
      { q: "Conjugue 'aller' au présent, 1ʳᵉ pers. plur.", options: ["allons", "allez", "vont", "vais"], answer: "allons" },
      { q: "Auteur de 'Le Petit Prince' ?", options: ["Camus", "Saint-Exupéry", "Sartre", "Prévert"], answer: "Saint-Exupéry" },
      { q: "Nature du mot 'rapidement' ?", options: ["nom", "adjectif", "adverbe", "verbe"], answer: "adverbe" },
      { q: "Un 'oxymore' est…", options: ["une rime", "une figure de style", "un synonyme", "un temps"], answer: "une figure de style" },
      { q: "Passé simple de 'être' (il/elle) ?", options: ["fut", "était", "sera", "a été"], answer: "fut" },
      { q: "'Quel' ou 'qu'elle' : '__ heure est-il ?'", options: ["quel", "quelle", "qu'elle", "quels"], answer: "quelle" },
      { q: "Le féminin de 'acteur' ?", options: ["acteure", "actrice", "acteuse", "actrise"], answer: "actrice" },
      { q: "Homophone de 'ces' ?", options: ["ses", "sait", "s'est", "toutes"], answer: "ses" },
    ],
  },
  {
    key: "Anglais", label: "Anglais", icon: Languages, color: "text-fuchsia-500",
    bank: [
      { q: "Traduction de 'pomme' ?", options: ["orange", "apple", "grape", "pear"], answer: "apple" },
      { q: "'She ___ to school every day.'", options: ["go", "goes", "going", "gone"], answer: "goes" },
      { q: "Passé de 'to eat' ?", options: ["eated", "eat", "ate", "eaten"], answer: "ate" },
      { q: "Traduction de 'demain' ?", options: ["today", "yesterday", "tomorrow", "tonight"], answer: "tomorrow" },
      { q: "'I ___ a book right now.'", options: ["read", "am reading", "reads", "was read"], answer: "am reading" },
      { q: "Contraire de 'happy' ?", options: ["angry", "sad", "sleepy", "shy"], answer: "sad" },
      { q: "Combien font 'twelve + three' ?", options: ["thirteen", "fourteen", "fifteen", "sixteen"], answer: "fifteen" },
      { q: "'They ___ finished their homework.'", options: ["has", "have", "having", "had been"], answer: "have" },
      { q: "Traduction de 'livre' (objet) ?", options: ["book", "pound", "free", "read"], answer: "book" },
      { q: "Pluriel de 'child' ?", options: ["childs", "childrens", "children", "childes"], answer: "children" },
      { q: "'If it rains, I ___ stay home.'", options: ["will", "would", "shall", "am"], answer: "will" },
      { q: "Traduction de 'jaune' ?", options: ["yellow", "green", "blue", "brown"], answer: "yellow" },
    ],
  },
  {
    key: "Mathématiques", label: "Mathématiques", icon: Calculator, color: "text-indigo-500",
    bank: [
      { q: "7 × 8 = ?", options: ["54", "56", "58", "64"], answer: "56" },
      { q: "Racine carrée de 144 ?", options: ["10", "11", "12", "13"], answer: "12" },
      { q: "15 % de 200 ?", options: ["20", "25", "30", "35"], answer: "30" },
      { q: "Aire d'un carré de côté 6 ?", options: ["12", "24", "30", "36"], answer: "36" },
      { q: "Somme des angles d'un triangle ?", options: ["90°", "180°", "270°", "360°"], answer: "180°" },
      { q: "π ≈ ?", options: ["2,72", "3,14", "3,41", "1,62"], answer: "3,14" },
      { q: "Résous : 2x + 4 = 10 →", options: ["1", "2", "3", "4"], answer: "3" },
      { q: "PGCD(12, 18) ?", options: ["2", "3", "6", "12"], answer: "6" },
      { q: "9² = ?", options: ["18", "72", "81", "99"], answer: "81" },
      { q: "Combien de faces a un cube ?", options: ["4", "6", "8", "12"], answer: "6" },
      { q: "1/2 + 1/4 = ?", options: ["1/6", "2/6", "3/4", "1"], answer: "3/4" },
      { q: "Périmètre d'un cercle de rayon 5 (≈) ?", options: ["15,7", "25", "31,4", "50"], answer: "31,4" },
    ],
  },
];

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function ChronoPage() {
  const [subject, setSubject] = useState<Subject | null>(null);
  const [phase, setPhase] = useState<"select" | "playing" | "finished">("select");
  const [questions, setQuestions] = useState<Q[]>([]);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(QUESTION_TIME);
  const [answered, setAnswered] = useState<string | null>(null);
  const [correct, setCorrect] = useState<boolean | null>(null);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const genQuestions = useServerFn(generateGameQuestions);

  const stopTimer = () => { if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; } };
  useEffect(() => () => stopTimer(), []);

  const startTimer = () => {
    stopTimer();
    setTimeLeft(QUESTION_TIME);
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) { stopTimer(); handleAnswer(null); return 0; }
        return t - 1;
      });
    }, 1000);
  };

  const startGame = async (s: Subject) => {
    setSubject(s);
    setLoading(s.key);
    let list: Q[] = [];
    try {
      const res = await genQuestions({ data: { game: "chrono", subject: s.key, count: TOTAL_QUESTIONS } });
      const aiQ = (res?.questions ?? [])
        .filter((q: any) => q && typeof q.q === "string" && Array.isArray(q.options) && q.options.length === 4 && q.options.includes(q.answer))
        .map((q: any) => ({ q: q.q as string, options: shuffle(q.options as string[]), answer: q.answer as string }));
      if (aiQ.length >= 5) list = aiQ.slice(0, TOTAL_QUESTIONS);
    } catch (e: any) {
      toast.message("Questions hors-ligne", { description: "IA indisponible, utilisation de la banque locale." });
    }
    if (list.length === 0) {
      list = shuffle(s.bank).slice(0, Math.min(TOTAL_QUESTIONS, s.bank.length))
        .map((q) => ({ ...q, options: shuffle(q.options) }));
    }
    setLoading(null);
    setQuestions(list);
    setIdx(0); setScore(0); setAnswered(null); setCorrect(null); setSaved(false);
    setPhase("playing");
    setTimeout(() => startTimer(), 50);
  };

  const current = questions[idx];

  const handleAnswer = (ans: string | null) => {
    stopTimer();
    if (!current) return;
    const ok = ans !== null && ans === current.answer;
    setAnswered(ans ?? "__timeout__");
    setCorrect(ok);
    if (ok) setScore((s) => s + 100 + timeLeft);
  };

  const next = () => {
    if (idx + 1 >= questions.length) { finish(); return; }
    setIdx((i) => i + 1);
    setAnswered(null); setCorrect(null);
    setTimeout(() => startTimer(), 50);
  };

  const finish = async () => {
    setPhase("finished");
    stopTimer();
    if (saved || !subject) return;
    try {
      await saveScore({ score, matiere: subject.key });
      setSaved(true);
    } catch (e: any) {
      toast.error(e?.message ?? "Erreur d'enregistrement du score");
    }
  };

  const reset = () => {
    setPhase("select"); setSubject(null); setQuestions([]);
    setIdx(0); setScore(0); setAnswered(null); setCorrect(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-primary/5 text-foreground">
      <header className="border-b border-border/60 bg-background/70 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3 sm:px-6 sm:py-4">
          <Link to="/games" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Jeux
          </Link>
          <div className="flex items-center gap-2">
            <Timer className="h-5 w-5 text-primary" />
            <span className="font-semibold">Chrono-Quiz</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6 sm:py-10">
        {phase === "select" && (
          <div className="space-y-5">
            <div>
              <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
                Choisis ta <span className="bg-gradient-to-r from-primary to-fuchsia-500 bg-clip-text text-transparent">matière</span>
              </h1>
              <p className="text-sm text-muted-foreground">15 secondes par question · 100 pts + bonus temps restant · 10 questions par partie</p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {SUBJECTS.map((s) => (
                <Card key={s.key} className={`group cursor-pointer border-border/60 transition hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-lg ${loading && loading !== s.key ? "opacity-50 pointer-events-none" : ""}`} onClick={() => !loading && startGame(s)}>
                  <CardContent className="flex items-center gap-4 p-5">
                    <div className={`rounded-xl bg-background p-3 ring-1 ring-border/60 ${s.color}`}>
                      <s.icon className="h-6 w-6" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold">{s.label}</div>
                      <div className="text-xs text-muted-foreground">
                        {loading === s.key ? "Génération des questions par l'IA…" : "Questions générées par l'IA à chaque partie"}
                      </div>
                    </div>
                    {loading === s.key
                      ? <Loader2 className="h-5 w-5 animate-spin text-primary" />
                      : <Play className="h-5 w-5 text-primary opacity-0 transition group-hover:opacity-100" />}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {phase === "playing" && current && subject && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Question {idx + 1} / {questions.length} · {subject.label}</span>
              <span className="font-semibold">{score} pts</span>
            </div>
            <Progress value={((idx + 1) / questions.length) * 100} className="h-1.5" />
            <Card className="border-primary/30">
              <CardContent className="space-y-5 p-6">
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className={subject.color}>{subject.label}</Badge>
                  <div className={`flex items-center gap-2 text-sm font-semibold ${timeLeft <= 5 ? "text-red-500 animate-pulse" : "text-primary"}`}>
                    <Timer className="h-4 w-4" /> {timeLeft}s
                  </div>
                </div>
                <Progress value={(timeLeft / QUESTION_TIME) * 100} className={`h-2 ${timeLeft <= 5 ? "[&>div]:bg-red-500" : ""}`} />
                <h2 className="text-lg font-semibold sm:text-xl">{current.q}</h2>
                <div className="grid gap-2 sm:grid-cols-2">
                  {current.options.map((opt) => {
                    const isSel = answered === opt;
                    const isRight = opt === current.answer;
                    const showState = answered !== null;
                    return (
                      <Button
                        key={opt}
                        variant="outline"
                        disabled={answered !== null}
                        onClick={() => handleAnswer(opt)}
                        className={`h-auto justify-start whitespace-normal p-4 text-left ${
                          showState && isRight ? "border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : ""
                        } ${showState && isSel && !isRight ? "border-red-500 bg-red-500/10 text-red-700 dark:text-red-300" : ""}`}
                      >
                        {opt}
                      </Button>
                    );
                  })}
                </div>
                {answered !== null && (
                  <div className="rounded-lg border border-border/60 bg-muted/30 p-3 text-sm">
                    {correct ? (
                      <span className="font-medium text-emerald-600 dark:text-emerald-400">
                        ✅ Bonne réponse ! +{100 + timeLeft} points
                      </span>
                    ) : (
                      <span className="font-medium text-red-600 dark:text-red-400">
                        ❌ Bonne réponse : <span className="font-semibold">{current.answer}</span>
                      </span>
                    )}
                  </div>
                )}
                {answered !== null && (
                  <Button onClick={next} className="w-full">
                    {idx + 1 >= questions.length ? "Voir mon score" : "Question suivante"}
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {phase === "finished" && (
          <Card className="border-primary/40 bg-gradient-to-br from-primary/5 to-fuchsia-500/5">
            <CardContent className="space-y-5 p-8 text-center">
              <Trophy className="mx-auto h-14 w-14 text-amber-500 animate-bounce" />
              <div>
                <div className="text-sm text-muted-foreground">Partie terminée</div>
                <div className="mt-1 text-5xl font-black tracking-tight">{score}</div>
                <div className="mt-1 text-sm text-muted-foreground">points · {subject?.label}</div>
              </div>
              {saved && <Badge variant="secondary" className="mx-auto">Score enregistré au classement</Badge>}
              <div className="flex flex-wrap justify-center gap-2">
                <Button onClick={() => subject && startGame(subject)} variant="outline"><RotateCw className="mr-1 h-4 w-4" /> Rejouer</Button>
                <Button onClick={reset}>Changer de matière</Button>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
