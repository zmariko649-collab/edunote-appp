import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  getMySession,
  listAllUsers,
  setUserBanned,
  setUserRole,
  generateLicence,
  listLicences,
} from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { Loader2, Shield, KeyRound, Users, Copy, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Administration — EduNote" }] }),
  component: AdminPanel,
});

type AdminUser = {
  user_id: string;
  email: string | null;
  full_name: string | null;
  plan: string;
  is_banned: boolean;
  created_at: string;
  role: "user" | "moderator" | "admin";
};

type Licence = {
  id: string;
  code: string;
  status: "unused" | "used";
  used_by: string | null;
  used_at: string | null;
  created_at: string;
};

function AdminPanel() {
  const navigate = useNavigate();
  const fetchSession = useServerFn(getMySession);
  const [checking, setChecking] = useState(true);
  const [allowed, setAllowed] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const s = await fetchSession();
        if (s.role !== "admin") {
          toast.error("Accès refusé — réservé aux administrateurs.");
          navigate({ to: "/dashboard", replace: true });
          return;
        }
        setAllowed(true);
      } catch {
        navigate({ to: "/dashboard", replace: true });
      } finally {
        setChecking(false);
      }
    })();
  }, []);

  if (checking) {
    return (
      <div className="mx-auto max-w-6xl p-8">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="mt-6 h-64 w-full" />
      </div>
    );
  }
  if (!allowed) return null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border/60">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm"><ArrowLeft className="h-4 w-4" /> Retour</Button>
            </Link>
            <div className="flex items-center gap-2 font-semibold">
              <Shield className="h-5 w-5 text-primary" />
              Administration
            </div>
          </div>
          <Badge>Admin</Badge>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        <Tabs defaultValue="users">
          <TabsList>
            <TabsTrigger value="users"><Users className="h-4 w-4" /> Utilisateurs</TabsTrigger>
            <TabsTrigger value="licences"><KeyRound className="h-4 w-4" /> Clés de licence</TabsTrigger>
          </TabsList>
          <TabsContent value="users" className="mt-6">
            <UsersTab />
          </TabsContent>
          <TabsContent value="licences" className="mt-6">
            <LicencesTab />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function UsersTab() {
  const list = useServerFn(listAllUsers);
  const ban = useServerFn(setUserBanned);
  const role = useServerFn(setUserRole);
  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = async () => {
    try {
      const data = await list();
      setUsers(data as AdminUser[]);
    } catch (e: any) {
      toast.error(e?.message ?? "Chargement impossible");
    }
  };
  useEffect(() => { load(); }, []);

  const toggleBan = async (u: AdminUser) => {
    setBusyId(u.user_id);
    try {
      await ban({ data: { userId: u.user_id, banned: !u.is_banned } });
      toast.success(u.is_banned ? "Utilisateur débanni" : "Utilisateur banni");
      await load();
    } catch (e: any) {
      toast.error(e?.message ?? "Échec");
    } finally { setBusyId(null); }
  };
  const promote = async (u: AdminUser) => {
    setBusyId(u.user_id);
    try {
      const newRole = u.role === "moderator" ? "user" : "moderator";
      await role({ data: { userId: u.user_id, role: newRole } });
      toast.success(newRole === "moderator" ? "Promu modérateur" : "Rétrogradé");
      await load();
    } catch (e: any) {
      toast.error(e?.message ?? "Échec");
    } finally { setBusyId(null); }
  };

  if (!users) return <Skeleton className="h-64 w-full" />;

  return (
    <Card>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-border/60 bg-muted/30 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Utilisateur</th>
                <th className="px-4 py-3">Rôle</th>
                <th className="px-4 py-3">Plan</th>
                <th className="px-4 py-3">Statut</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.user_id} className="border-b border-border/40 last:border-0">
                  <td className="px-4 py-3">
                    <div className="font-medium">{u.full_name || "—"}</div>
                    <div className="text-xs text-muted-foreground">{u.email}</div>
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant={u.role === "admin" ? "default" : u.role === "moderator" ? "secondary" : "outline"}>
                      {u.role}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 capitalize">{u.plan}</td>
                  <td className="px-4 py-3">
                    {u.is_banned ? <Badge variant="destructive">Banni</Badge> : <span className="text-muted-foreground">Actif</span>}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-2">
                      {u.role !== "admin" && (
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={busyId === u.user_id}
                          onClick={() => promote(u)}
                        >
                          {u.role === "moderator" ? "Retirer modérateur" : "Nommer modérateur"}
                        </Button>
                      )}
                      {u.role !== "admin" && (
                        <Button
                          size="sm"
                          variant={u.is_banned ? "secondary" : "destructive"}
                          disabled={busyId === u.user_id}
                          onClick={() => toggleBan(u)}
                        >
                          {busyId === u.user_id ? <Loader2 className="h-3 w-3 animate-spin" /> : u.is_banned ? "Débannir" : "Bannir"}
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

function LicencesTab() {
  const list = useServerFn(listLicences);
  const gen = useServerFn(generateLicence);
  const [items, setItems] = useState<Licence[] | null>(null);
  const [generating, setGenerating] = useState(false);

  const load = async () => {
    try { setItems((await list()) as Licence[]); }
    catch (e: any) { toast.error(e?.message ?? "Chargement impossible"); }
  };
  useEffect(() => { load(); }, []);

  const onGenerate = async () => {
    setGenerating(true);
    try {
      const l = (await gen()) as Licence;
      toast.success(`Clé générée : ${l.code}`);
      await load();
    } catch (e: any) {
      toast.error(e?.message ?? "Échec");
    } finally { setGenerating(false); }
  };

  const copy = (code: string) => {
    navigator.clipboard.writeText(code).then(() => toast.success("Copié"));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="flex flex-wrap items-center justify-between gap-3 p-6">
          <div>
            <div className="font-medium">Générer une nouvelle clé</div>
            <div className="text-sm text-muted-foreground">Format : EDUNOTE-XXXX-XXXX. Génération illimitée.</div>
          </div>
          <Button onClick={onGenerate} disabled={generating}>
            {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <><KeyRound className="h-4 w-4" /> Générer une clé</>}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {!items ? (
            <div className="p-6"><Skeleton className="h-32 w-full" /></div>
          ) : items.length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">Aucune clé pour le moment.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border/60 bg-muted/30 text-left text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3">Code</th>
                    <th className="px-4 py-3">Statut</th>
                    <th className="px-4 py-3">Créée le</th>
                    <th className="px-4 py-3">Utilisée le</th>
                    <th className="px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((l) => (
                    <tr key={l.id} className="border-b border-border/40 last:border-0">
                      <td className="px-4 py-3 font-mono text-xs">{l.code}</td>
                      <td className="px-4 py-3">
                        {l.status === "used"
                          ? <Badge variant="secondary">Utilisée</Badge>
                          : <Badge>Non utilisée</Badge>}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{new Date(l.created_at).toLocaleString("fr-FR")}</td>
                      <td className="px-4 py-3 text-muted-foreground">{l.used_at ? new Date(l.used_at).toLocaleString("fr-FR") : "—"}</td>
                      <td className="px-4 py-3 text-right">
                        <Button size="sm" variant="ghost" onClick={() => copy(l.code)}><Copy className="h-3.5 w-3.5" /></Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}