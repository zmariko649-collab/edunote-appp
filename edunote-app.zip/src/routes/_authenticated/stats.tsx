import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { FileText, Trophy, Gamepad2, Zap, Flame } from "lucide-react";

const WHATSAPP_CHANNEL_URL = "https://whatsapp.com/channel/0029VbD4MGs0VycB9SBKuA2s";

export const Route = createFileRoute("/_authenticated/stats")({
  head: () => ({ meta: [{ title: "Statistiques — EduNote" }] }),
  component: StatsPage,
});

type Stats = {
  documents: number;
  quizAvg: number | null;
  gamesPlayed: number;
  creditsUsed: number;
  streakDays: number;
  activeDays: Set<number>; // 0=Mon..6=Sun current week
};

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.174.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12.05 21.785h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.999-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.886 9.884zm8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
    </svg>
  );
}

function StatsPage() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    (async () => {
      const { data: user } = await supabase.auth.getUser();
      const uid = user.user?.id;
      const [{ data: courses }, { data: attempts }, { data: leader }, { data: profile }] = await Promise.all([
        supabase.from("courses").select("id, created_at"),
        supabase.from("quiz_attempts").select("is_correct, answered_at").eq("user_id", uid ?? ""),
        supabase.from("leaderboard").select("id").eq("user_id", uid ?? ""),
        supabase.from("profiles").select("credits").maybeSingle(),
      ]);

      const attemptsArr = attempts ?? [];
      const correct = attemptsArr.filter((a: any) => a.is_correct).length;
      const quizAvg = attemptsArr.length ? Math.round((correct / attemptsArr.length) * 100) : null;

      // Active days this week (Mon=0..Sun=6) from courses + attempts
      const now = new Date();
      const monday = new Date(now);
      const day = (now.getDay() + 6) % 7;
      monday.setHours(0, 0, 0, 0);
      monday.setDate(now.getDate() - day);
      const activeDays = new Set<number>();
      const allDates = [
        ...(courses ?? []).map((c: any) => c.created_at),
        ...attemptsArr.map((a: any) => a.answered_at),
      ];
      for (const iso of allDates) {
        const d = new Date(iso);
        if (d >= monday) activeDays.add((d.getDay() + 6) % 7);
      }

      // Streak: consecutive days back from today with any activity
      const daysSet = new Set(allDates.map((iso) => new Date(iso).toDateString()));
      let streak = 0;
      const cursor = new Date(); cursor.setHours(0,0,0,0);
      while (daysSet.has(cursor.toDateString())) {
        streak++;
        cursor.setDate(cursor.getDate() - 1);
      }

      const creditsUsed = Math.max(0, 10 - (profile?.credits ?? 10)) + (courses?.length ?? 0) * 5;

      setStats({
        documents: courses?.length ?? 0,
        quizAvg,
        gamesPlayed: leader?.length ?? 0,
        creditsUsed,
        streakDays: streak,
        activeDays,
      });
    })();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 via-background to-background">
      <header className="mx-auto max-w-3xl px-4 pt-6 sm:px-6 sm:pt-8">
        <h1 className="text-2xl font-bold tracking-tight">Statistiques 📊</h1>
        <p className="text-sm text-muted-foreground">Tes progrès de révision.</p>
      </header>

      <main className="mx-auto max-w-3xl space-y-5 px-4 py-5 sm:px-6">
        {/* Streak banner */}
        <Card className="overflow-hidden rounded-3xl border-none bg-gradient-to-br from-orange-400 via-amber-500 to-yellow-500 text-white shadow-xl">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white/20 backdrop-blur">
                <Flame className="h-6 w-6" />
              </div>
              <div className="min-w-0">
                <div className="text-lg font-bold">
                  🔥 Streak de révision !
                </div>
                <div className="text-sm text-white/85">
                  {stats ? `${stats.streakDays} jour${stats.streakDays > 1 ? "s" : ""} de suite. Continue comme ça !` : "…"}
                </div>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between gap-1">
              {["L","M","M","J","V","S","D"].map((d, i) => {
                const active = stats?.activeDays.has(i);
                return (
                  <div key={i} className="flex flex-1 flex-col items-center gap-1.5">
                    <div className={`grid h-9 w-9 place-items-center rounded-full text-xs font-bold ${active ? "bg-white text-orange-600 shadow" : "bg-white/15 text-white/80"}`}>
                      {active ? "✓" : d}
                    </div>
                    <span className="text-[10px] text-white/70">{d}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* 2x2 stat grid */}
        {stats === null ? (
          <div className="grid grid-cols-2 gap-3">
            {[0,1,2,3].map(i => <Skeleton key={i} className="h-28 rounded-2xl" />)}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <StatTile icon={<FileText className="h-5 w-5" />} tint="from-sky-500/15 to-blue-500/10" color="text-sky-600" label="Documents importés" value={stats.documents} />
            <StatTile icon={<Trophy className="h-5 w-5" />} tint="from-emerald-500/15 to-teal-500/10" color="text-emerald-600" label="Score moyen Quiz" value={stats.quizAvg === null ? "—" : `${stats.quizAvg}%`} />
            <StatTile icon={<Gamepad2 className="h-5 w-5" />} tint="from-fuchsia-500/15 to-purple-500/10" color="text-fuchsia-600" label="Parties jouées" value={stats.gamesPlayed} />
            <StatTile icon={<Zap className="h-5 w-5" />} tint="from-amber-500/15 to-orange-500/10" color="text-amber-600" label="Crédits utilisés" value={stats.creditsUsed} />
          </div>
        )}

        {/* WhatsApp banner */}
        <a href={WHATSAPP_CHANNEL_URL} target="_blank" rel="noopener noreferrer" className="block">
          <Card className="overflow-hidden rounded-3xl border-none bg-gradient-to-br from-emerald-600 via-green-600 to-teal-600 text-white shadow-xl">
            <CardContent className="flex items-center gap-4 p-5">
              <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/20 backdrop-blur">
                <WhatsAppIcon className="h-6 w-6" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-bold">Récupère des crédits gratuits</div>
                <div className="mt-0.5 text-xs text-white/85">Codes promo & clés Premium sur notre canal WhatsApp.</div>
              </div>
              <span className="shrink-0 rounded-full bg-white px-3 py-1.5 text-xs font-bold text-emerald-700">Rejoindre</span>
            </CardContent>
          </Card>
        </a>
      </main>
    </div>
  );
}

function StatTile({ icon, label, value, tint, color }: { icon: React.ReactNode; label: string; value: string | number; tint: string; color: string }) {
  return (
    <Card className="overflow-hidden rounded-2xl border-border/60">
      <div className={`bg-gradient-to-br ${tint}`}>
        <CardContent className="p-4">
          <div className={`inline-flex rounded-xl bg-background/80 p-2 ${color}`}>{icon}</div>
          <div className="mt-3 text-2xl font-bold">{value}</div>
          <div className="text-xs text-muted-foreground">{label}</div>
        </CardContent>
      </div>
    </Card>
  );
}