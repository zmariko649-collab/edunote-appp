import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { getMyReferrals } from "@/lib/referral.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ArrowLeft, Gift, Share2, Users, Coins, Sparkles } from "lucide-react";

export const Route = createFileRoute("/_authenticated/referral")({
  head: () => ({ meta: [{ title: "Parrainage — EduNote" }] }),
  component: ReferralPage,
});

type Data = Awaited<ReturnType<typeof getMyReferrals>>;

const BONUS = 25;
const NEXT_TIER = 5; // filleuls pour palier

function ReferralPage() {
  const fetchRefs = useServerFn(getMyReferrals);
  const [data, setData] = useState<Data | null>(null);

  useEffect(() => {
    fetchRefs().then(setData).catch((e) => toast.error(e?.message ?? "Erreur de chargement"));
  }, []);

  const code = data?.code ?? "";
  const link = code ? `https://edunote-app.lovable.app/auth?ref=${code}` : "";
  const count = data?.referrals.length ?? 0;
  const earned = count * BONUS;
  const progress = Math.min(100, (count % NEXT_TIER) * (100 / NEXT_TIER));

  const shareMessage = link
    ? `🚀 Réussis tes examens avec EduNote !\n\nJ'utilise cette application incroyable pour résumer mes cours en quelques secondes, générer des quiz automatiques et même jouer pour réviser mes maths et mon anglais.\n\nViens me rejoindre pour booster tes notes et gagner des crédits gratuits avec mon lien : ${link}`
    : "";

  const shareWithFriends = () => {
    if (!shareMessage) return;
    navigator.clipboard.writeText(shareMessage).then(
      () => toast.success("Message copié ! Tu peux maintenant le coller dans tes groupes WhatsApp."),
      () => toast.error("Impossible de copier le message"),
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border/60">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-6 py-4">
          <Link to="/dashboard" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Retour au tableau de bord
          </Link>
          <div className="flex items-center gap-2 text-sm font-semibold">
            <img src="/favicon.png" alt="EduNote" className="h-6 w-6 rounded-md" />
            EduNote
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-6 py-10">
        <div className="flex items-center gap-3">
          <div className="rounded-2xl bg-primary/10 p-3 text-primary"><Gift className="h-6 w-6" /></div>
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Programme de parrainage</h1>
            <p className="text-sm text-muted-foreground">Invite tes amis et gagne des crédits gratuits.</p>
          </div>
        </div>

        {data === null ? (
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {[0, 1, 2].map((i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}
          </div>
        ) : (
          <>
            <div className="mt-8 grid gap-4 md:grid-cols-3">
              <StatCard icon={<Users className="h-4 w-4 text-primary" />} label="Filleuls inscrits" value={count} />
              <StatCard icon={<Coins className="h-4 w-4 text-primary" />} label="Crédits gagnés" value={earned} />
              <StatCard
                icon={<Sparkles className="h-4 w-4 text-primary" />}
                label="Statut"
                value={data.plan === "premium" ? "Premium" : "Gratuit"}
                valueBadge={data.plan === "premium"}
              />
            </div>

            <Card className="mt-6">
              <CardContent className="p-5">
                <div className="text-sm font-semibold">Ton lien unique</div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Chaque ami inscrit via ton lien te donne <strong>{BONUS} crédits</strong>, et il démarre avec <strong>25 crédits</strong> (au lieu de 10).
                </p>
                <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                  <Input readOnly value={link} className="font-mono text-xs" onFocus={(e) => e.currentTarget.select()} />
                  <Button onClick={shareWithFriends} className="shrink-0"><Share2 className="h-4 w-4" /> Partager avec mes amis</Button>
                </div>
                <div className="mt-3 text-xs text-muted-foreground">
                  Ton code : <span className="font-mono font-semibold text-foreground">{code || "—"}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardContent className="p-5">
                <div className="flex items-center justify-between text-sm">
                  <div className="font-semibold">Prochain palier</div>
                  <div className="text-muted-foreground">{count % NEXT_TIER}/{NEXT_TIER} filleuls</div>
                </div>
                <Progress value={progress} className="mt-3 h-2" />
                <p className="mt-2 text-xs text-muted-foreground">
                  Encore {NEXT_TIER - (count % NEXT_TIER)} inscription{NEXT_TIER - (count % NEXT_TIER) > 1 ? "s" : ""} pour débloquer un bonus supplémentaire.
                </p>
              </CardContent>
            </Card>

            <section className="mt-8">
              <h2 className="text-lg font-semibold">Historique des filleuls</h2>
              {count === 0 ? (
                <Card className="mt-4">
                  <CardContent className="p-8 text-center text-sm text-muted-foreground">
                    Aucun filleul pour le moment. Partage ton lien pour commencer à gagner des crédits.
                  </CardContent>
                </Card>
              ) : (
                <Card className="mt-4 overflow-hidden">
                  <div className="divide-y divide-border/60">
                    {data.referrals.map((r, i) => (
                      <div key={i} className="flex items-center justify-between gap-3 px-5 py-3 text-sm">
                        <div className="min-w-0">
                          <div className="truncate font-medium">{r.full_name || r.email || "Utilisateur"}</div>
                          {r.email && r.full_name && <div className="truncate text-xs text-muted-foreground">{r.email}</div>}
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <span className="text-xs text-muted-foreground">
                            {new Date(r.created_at).toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" })}
                          </span>
                          <Badge variant="secondary">+{BONUS} crédits</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </section>
          </>
        )}
      </main>
    </div>
  );
}

function StatCard({ icon, label, value, valueBadge }: { icon: React.ReactNode; label: string; value: string | number; valueBadge?: boolean }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">{icon}{label}</div>
        <div className="mt-2 text-3xl font-semibold">
          {valueBadge ? <Badge className="text-base">{value}</Badge> : value}
        </div>
      </CardContent>
    </Card>
  );
}