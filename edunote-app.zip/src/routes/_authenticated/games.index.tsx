import { createFileRoute, Link } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Leaderboard } from "@/components/leaderboard";
import { ArrowLeft, Sparkles, Timer, Calculator, Languages, Trophy, Zap, Play } from "lucide-react";

export const Route = createFileRoute("/_authenticated/games/")({
  head: () => ({ meta: [{ title: "Jeux éducatifs — EduNote" }] }),
  component: GamesHub,
});

const GAMES = [
  {
    to: "/games/chrono" as const,
    title: "Chrono-Quiz",
    desc: "15 secondes par question. Bonus pour la rapidité !",
    icon: Timer,
    gradient: "from-primary/20 to-fuchsia-500/20",
    accent: "text-primary",
  },
  {
    to: "/games/math" as const,
    title: "Math Dash",
    desc: "Calcul mental & algèbre avec combo streak x2.",
    icon: Calculator,
    gradient: "from-emerald-500/20 to-cyan-500/20",
    accent: "text-emerald-500",
  },
  {
    to: "/games/english" as const,
    title: "Word Master",
    desc: "QCM de vocabulaire & phrases à trous en anglais.",
    icon: Languages,
    gradient: "from-amber-500/20 to-rose-500/20",
    accent: "text-amber-500",
  },
];

function GamesHub() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-primary/5 text-foreground">
      <header className="border-b border-border/60 bg-background/70 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3 sm:px-6 sm:py-4">
          <Link to="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Retour
          </Link>
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <span className="font-semibold">Jeux Éducatifs</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-10">
        <div className="mb-6">
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Choisis ton <span className="bg-gradient-to-r from-primary to-fuchsia-500 bg-clip-text text-transparent">terrain de jeu</span>
          </h1>
          <p className="text-sm text-muted-foreground">Apprends en t'amusant. Tous les scores comptent au classement global.</p>
        </div>

        <Tabs defaultValue="games">
          <TabsList className="grid w-full grid-cols-2 sm:w-auto">
            <TabsTrigger value="games"><Play className="mr-1 h-4 w-4" /> Jeux</TabsTrigger>
            <TabsTrigger value="leaderboard"><Trophy className="mr-1 h-4 w-4" /> Classement</TabsTrigger>
          </TabsList>

          <TabsContent value="games" className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {GAMES.map((g) => (
              <Link key={g.to} to={g.to}>
                <Card className={`group relative overflow-hidden border-border/60 transition hover:-translate-y-1 hover:border-primary/50 hover:shadow-lg`}>
                  <div className={`absolute inset-0 -z-10 bg-gradient-to-br ${g.gradient} opacity-60 transition group-hover:opacity-100`} />
                  <CardContent className="space-y-3 p-6">
                    <div className={`inline-flex rounded-xl bg-background/70 p-3 ${g.accent}`}>
                      <g.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-semibold">{g.title}</h3>
                        <Badge variant="secondary" className="gap-1"><Zap className="h-3 w-3 text-amber-500" />Beta</Badge>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">{g.desc}</p>
                    </div>
                    <div className="pt-2 text-sm font-medium text-primary opacity-0 transition group-hover:opacity-100">
                      Jouer →
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </TabsContent>

          <TabsContent value="leaderboard" className="mt-6">
            <Leaderboard />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}