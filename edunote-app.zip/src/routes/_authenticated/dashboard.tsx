import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { createCourseFromInput } from "@/lib/ai.functions";
import { redeemLicenseKey } from "@/lib/license.functions";
import { getMySession } from "@/lib/admin.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { FREE_LIMITS, currentMonthKey } from "@/lib/quotas";
import { Loader2, Plus, LogOut, Sparkles, FileText, Mic, Type, BookOpen, Shield, Coins, Gift, Copy, KeyRound, Gamepad2, Calculator, Languages, Home, User, Zap, FilePlus2, PencilLine, ArrowUpRight } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { WifiOff, CloudOff } from "lucide-react";
import { readOfflineHistory, useOnlineStatus, type OfflineEntry } from "@/lib/offline";

const MYCHARIOW_URL = "https://ghosthu.mychariow.co/prd_x5svxjot/checkout";
const WHATSAPP_CHANNEL_URL = "https://whatsapp.com/channel/0029VbD4MGs0VycB9SBKuA2s";
const WELCOME_BANNER_KEY = "has_seen_welcome_banner";

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.174.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12.05 21.785h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.999-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.886 9.884zm8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
    </svg>
  );
}

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Tableau de bord — EduNote" }] }),
  component: Dashboard,
});

type Course = { id: string; title: string; subject: string | null; folder: string | null; source_type: string; created_at: string };
type Usage = { summaries_used: number; flashcards_used: number; chat_messages_used: number; quizzes_used: number };
type Profile = { plan: string; full_name: string | null; email: string | null; credits: number; referral_code: string | null };

function Dashboard() {
  const navigate = useNavigate();
  const fetchSession = useServerFn(getMySession);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [role, setRole] = useState<"user" | "moderator" | "admin">("user");
  const [courses, setCourses] = useState<Course[] | null>(null);
  const [usage, setUsage] = useState<Usage>({ summaries_used: 0, flashcards_used: 0, chat_messages_used: 0, quizzes_used: 0 });
  const [showImport, setShowImport] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const online = useOnlineStatus();
  const [offlineEntries, setOfflineEntries] = useState<OfflineEntry[]>([]);

  useEffect(() => {
    if (!online) setOfflineEntries(readOfflineHistory());
  }, [online]);

  const load = async () => {
    // Vérifie d'abord ban + rôle côté serveur
    try {
      const s = await fetchSession();
      if (s.isBanned) {
        await supabase.auth.signOut();
        toast.error("Votre compte a été banni. Contactez le support.");
        navigate({ to: "/auth", replace: true });
        return;
      }
      setRole(s.role);
    } catch {}
    const { data: p } = await supabase.from("profiles").select("plan, full_name, email, credits, referral_code").maybeSingle();
    setProfile(p as Profile | null);
    const { data: c } = await supabase.from("courses").select("id, title, subject, folder, source_type, created_at").order("created_at", { ascending: false });
    setCourses((c ?? []) as Course[]);
    const { data: u } = await supabase.from("usage_limits").select("*").eq("month", currentMonthKey()).maybeSingle();
    if (u) setUsage(u as Usage);
  };

  useEffect(() => {
    load();
    const p = new URLSearchParams(window.location.search);
    if (p.get("payment") === "success") toast.success("Paiement reçu. Votre plan sera activé après confirmation.");
    try {
      if (!localStorage.getItem(WELCOME_BANNER_KEY)) setShowWelcome(true);
    } catch {}
  }, []);

  const dismissWelcome = () => {
    try { localStorage.setItem(WELCOME_BANNER_KEY, "1"); } catch {}
    setShowWelcome(false);
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  };

  const isPremium = profile?.plan === "premium";
  const credits = profile?.credits ?? 0;
  const outOfCredits = !isPremium && credits < 5;

  const firstName = profile?.full_name?.split(" ")[0] || "toi";
  const now = Date.now();
  const coursesThisWeek = (courses ?? []).filter(c => now - new Date(c.created_at).getTime() < 7 * 24 * 3600 * 1000).length;
  const weekGoal = 5;
  const weekPct = Math.min(100, Math.round((coursesThisWeek / weekGoal) * 100));

  const openImportWith = (initialTab: "text" | "file") => {
    setImportTab(initialTab);
    setShowImport(true);
  };
  const [importTab, setImportTab] = useState<"text" | "file">("text");

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 via-background to-background text-foreground pb-24">
      {/* Header */}
      <header className="mx-auto max-w-3xl px-4 pt-6 sm:px-6 sm:pt-8">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <h1 className="truncate text-xl font-bold tracking-tight sm:text-2xl">
              Salut {firstName} <span aria-hidden>👋</span>
            </h1>
            <p className="text-sm text-muted-foreground">Prêt à réviser ?</p>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {!online && (
              <span className="hidden items-center gap-1 rounded-full border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-xs text-amber-700 sm:inline-flex dark:text-amber-300">
                <WifiOff className="h-3 w-3" /> Offline
              </span>
            )}
            {isPremium ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-3 py-1.5 text-xs font-semibold text-white shadow-sm">
                <Sparkles className="h-3.5 w-3.5" /> Premium
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1.5 text-sm font-semibold text-primary ring-1 ring-primary/20">
                <Coins className="h-4 w-4" /> {credits} crédits
              </span>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-5 px-4 py-5 sm:px-6 sm:py-6">
        {!online && (
          <Card className="rounded-2xl border-amber-500/40 bg-amber-500/5">
            <CardContent className="flex items-start gap-3 p-4 text-sm">
              <CloudOff className="mt-0.5 h-5 w-5 text-amber-600 dark:text-amber-400" />
              <div>
                <div className="font-medium">Mode Hors-ligne activé</div>
                <div className="text-muted-foreground">La génération nécessite une connexion.</div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Progrès de révision */}
        <Card className="rounded-2xl border-border/60 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-sm font-semibold">Progression de la semaine</div>
                <div className="mt-0.5 text-xs text-muted-foreground">
                  Tu as révisé <strong className="text-foreground">{coursesThisWeek}</strong> cours cette semaine
                </div>
              </div>
              {!isPremium && (
                <a href={WHATSAPP_CHANNEL_URL} target="_blank" rel="noopener noreferrer" className="shrink-0">
                  <Button size="sm" variant="outline" className="rounded-full">
                    <Zap className="h-4 w-4 text-amber-500" /> Recharger
                  </Button>
                </a>
              )}
            </div>
            <Progress value={weekPct} className="mt-3" />
            <div className="mt-1 text-[11px] text-muted-foreground">Objectif : {weekGoal} cours / semaine</div>
          </CardContent>
        </Card>

        {/* Carte d'action principale */}
        <Card className="overflow-hidden rounded-3xl border-none bg-gradient-to-br from-primary via-primary to-fuchsia-600 text-primary-foreground shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <div className="rounded-2xl bg-white/15 p-3 backdrop-blur">
                <Sparkles className="h-6 w-6" />
              </div>
              <div className="min-w-0 flex-1">
                <h2 className="text-lg font-bold leading-tight sm:text-xl">Importer un nouveau cours</h2>
                <p className="mt-1 text-sm text-white/80">Transforme ton cours en Fiche ou Quiz {isPremium ? "" : "(5 crédits)"}</p>
              </div>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <button
                onClick={() => openImportWith("file")}
                disabled={!online}
                className="flex items-center justify-center gap-2 rounded-2xl bg-white/15 px-3 py-3 text-sm font-semibold backdrop-blur transition hover:bg-white/25 disabled:opacity-50"
              >
                <FilePlus2 className="h-4 w-4" /> Importer PDF
              </button>
              <button
                onClick={() => openImportWith("text")}
                disabled={!online}
                className="flex items-center justify-center gap-2 rounded-2xl bg-white text-primary px-3 py-3 text-sm font-semibold shadow transition hover:bg-white/90 disabled:opacity-50"
              >
                <PencilLine className="h-4 w-4" /> Saisir texte
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Jeux */}
        <section>
          <div className="mb-3 flex items-end justify-between gap-3">
            <h2 className="text-base font-bold">🎮 Espace Jeux Éducatifs</h2>
            <Link to="/games" className="text-xs font-semibold text-primary hover:underline">Tout voir →</Link>
          </div>
          <div className="-mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2 sm:mx-0 sm:grid sm:grid-cols-2 sm:overflow-visible sm:px-0">
            <Link to="/games/math" className="min-w-[80%] snap-start sm:min-w-0">
              <Card className="h-full overflow-hidden rounded-2xl border-border/60 transition hover:-translate-y-0.5 hover:shadow-lg">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 to-cyan-500/20" />
                  <CardContent className="relative flex items-center gap-3 p-4">
                    <div className="rounded-xl bg-background/80 p-2.5 text-emerald-600 dark:text-emerald-400">
                      <Calculator className="h-6 w-6" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-semibold">Math Dash</div>
                      <div className="truncate text-xs text-muted-foreground">Calcul mental & algèbre</div>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                  </CardContent>
                </div>
              </Card>
            </Link>
            <Link to="/games/english" className="min-w-[80%] snap-start sm:min-w-0">
              <Card className="h-full overflow-hidden rounded-2xl border-border/60 transition hover:-translate-y-0.5 hover:shadow-lg">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 to-rose-500/20" />
                  <CardContent className="relative flex items-center gap-3 p-4">
                    <div className="rounded-xl bg-background/80 p-2.5 text-amber-600 dark:text-amber-400">
                      <Languages className="h-6 w-6" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-semibold">Word Master</div>
                      <div className="truncate text-xs text-muted-foreground">Vocabulaire & définitions</div>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                  </CardContent>
                </div>
              </Card>
            </Link>
          </div>
        </section>

        {/* WhatsApp community banner */}
        <a href={WHATSAPP_CHANNEL_URL} target="_blank" rel="noopener noreferrer" className="block">
          <Card className="overflow-hidden rounded-3xl border-none bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 text-white shadow-xl">
            <CardContent className="flex items-center gap-4 p-5">
              <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 text-slate-900 shadow-lg">
                <Zap className="h-6 w-6" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate font-bold">Rejoins le Canal GHOST TECH / EduNote</div>
                <div className="mt-0.5 text-xs text-slate-300">Codes promo, crédits gratuits et mises à jour.</div>
              </div>
              <span className="shrink-0 inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 px-3 py-2 text-xs font-bold text-slate-900 shadow">
                <WhatsAppIcon className="h-4 w-4" /> Rejoindre
              </span>
            </CardContent>
          </Card>
        </a>

        {!isPremium && (
          <Card className="rounded-2xl border-primary/30 bg-primary/5">
            <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div className="flex items-center gap-3">
                <Sparkles className="h-5 w-5 text-primary" />
                <div className="text-sm">
                  <div className="font-semibold">Passe au Premium — accès illimité.</div>
                  <div className="text-xs text-muted-foreground">Active ta clé MyChariow en un clic.</div>
                </div>
              </div>
              <Button size="sm" onClick={() => setShowUpgrade(true)}>Activer</Button>
            </CardContent>
          </Card>
        )}

        {!isPremium && profile?.referral_code && (
          <ReferralCard code={profile.referral_code} />
        )}

        {/* Quick access to library */}
        <Link to="/library" className="block">
          <Card className="rounded-2xl border-border/60 transition hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-md">
            <CardContent className="flex items-center gap-3 p-4">
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-primary/10 text-primary">
                <BookOpen className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-semibold">Ma bibliothèque</div>
                <div className="text-xs text-muted-foreground">
                  {courses === null ? "…" : `${courses.length} cours enregistré${(courses?.length ?? 0) > 1 ? "s" : ""}`}
                </div>
              </div>
              <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
            </CardContent>
          </Card>
        </Link>
      </main>

      {/* Floating Action Button */}
      <button
        onClick={() => setShowImport(true)}
        disabled={!online}
        aria-label="Nouveau cours"
        className="fixed bottom-24 right-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-primary to-fuchsia-600 text-white shadow-2xl shadow-primary/40 transition hover:scale-105 active:scale-95 disabled:opacity-50 sm:right-8"
      >
        <Plus className="h-6 w-6" />
      </button>

      {showImport && (
        <ImportDialog
          plan={profile?.plan ?? "free"}
          credits={credits}
          initialTab={importTab}
          onClose={() => setShowImport(false)}
          onDone={() => { setShowImport(false); load(); }}
          onQuotaExceeded={() => { setShowImport(false); setShowUpgrade(true); }}
        />
      )}
      {showUpgrade && (
        <UpgradeDialog
          onClose={() => setShowUpgrade(false)}
          onActivated={() => { setShowUpgrade(false); load(); }}
        />
      )}
      {showWelcome && <WelcomeBanner onClose={dismissWelcome} />}
    </div>
  );
}

function BottomTab({ icon, label, to, active, onClick }: { icon: React.ReactNode; label: string; to?: string; active?: boolean; onClick?: () => void }) {
  const cls = `flex flex-col items-center justify-center gap-0.5 py-2.5 text-[11px] font-medium transition ${active ? "text-primary" : "text-muted-foreground hover:text-foreground"}`;
  if (to) return <Link to={to} className={cls} onClick={onClick}>{icon}<span>{label}</span></Link>;
  return <button type="button" onClick={onClick} className={cls}>{icon}<span>{label}</span></button>;
}

function ProfileTab({ role, onSignOut }: { role: "user" | "moderator" | "admin"; onSignOut: () => void }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="flex flex-col items-center justify-center gap-0.5 py-2.5 text-[11px] font-medium text-muted-foreground transition hover:text-foreground">
        <User className="h-5 w-5" />
        <span>Profil</span>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" side="top" className="w-56 mb-2">
        <DropdownMenuItem asChild>
          <Link to="/settings"><KeyRound className="h-4 w-4" /> Licence & compte</Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/referral"><Gift className="h-4 w-4" /> Parrainage</Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <a href={WHATSAPP_CHANNEL_URL} target="_blank" rel="noopener noreferrer">
            <WhatsAppIcon className="h-4 w-4 text-green-600" /> Support WhatsApp
          </a>
        </DropdownMenuItem>
        {role === "admin" && (
          <DropdownMenuItem asChild>
            <Link to="/admin"><Shield className="h-4 w-4" /> Admin</Link>
          </DropdownMenuItem>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={onSignOut}>
          <LogOut className="h-4 w-4" /> Se déconnecter
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function WelcomeBanner({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" role="dialog" aria-modal="true">
      <div className="relative w-full max-w-md rounded-2xl border border-border bg-background p-6 shadow-2xl">
        <button
          onClick={onClose}
          aria-label="Fermer"
          className="absolute right-3 top-3 rounded-md p-1 text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          ✕
        </button>
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-green-500/10">
          <WhatsAppIcon className="h-8 w-8 text-green-600" />
        </div>
        <h2 className="text-center text-xl font-semibold tracking-tight">🎁 Cadeau de bienvenue !</h2>
        <p className="mt-3 text-center text-sm text-muted-foreground">
          Rejoins notre chaîne WhatsApp officielle. C'est là-bas que nous publions régulièrement les nouvelles mises à jour,
          des <strong className="text-foreground">clés de licence gratuites</strong> et des
          <strong className="text-foreground"> codes de réduction exclusifs</strong> pour passer Premium gratuitement !
        </p>
        <a
          href={WHATSAPP_CHANNEL_URL}
          target="_blank"
          rel="noopener noreferrer"
          onClick={onClose}
          className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg bg-green-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-green-700"
        >
          <WhatsAppIcon className="h-5 w-5" /> Rejoindre la chaîne WhatsApp 🚀
        </a>
        <button
          onClick={onClose}
          className="mt-2 w-full rounded-lg px-4 py-2 text-sm text-muted-foreground hover:text-foreground"
        >
          Plus tard
        </button>
      </div>
    </div>
  );
}

function QuotaCard({ label, used, max }: { label: string; used: number; max: number }) {
  const pct = Math.min(100, Math.round((used / max) * 100));
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">{label}</span>
          <span className="font-medium">{used}/{max}</span>
        </div>
        <Progress value={pct} className="mt-3" />
      </CardContent>
    </Card>
  );
}

function ImportDialog({
  onClose,
  onDone,
  plan,
  credits,
  onQuotaExceeded,
  initialTab,
}: {
  onClose: () => void;
  onDone: () => void;
  plan: string;
  credits: number;
  onQuotaExceeded: () => void;
  initialTab?: "text" | "file";
}) {
  const navigate = useNavigate();
  const create = useServerFn(createCourseFromInput);
  const [tab, setTab] = useState<"text" | "file">(initialTab ?? "text");
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [text, setText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [phase, setPhase] = useState<"idle" | "uploading" | "processing" | "error">("idle");
  const [progress, setProgress] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fileToBase64 = (f: File, onProgress: (pct: number) => void) =>
    new Promise<string>((resolve, reject) => {
      const r = new FileReader();
      r.onprogress = (ev) => {
        if (ev.lengthComputable) onProgress(Math.round((ev.loaded / ev.total) * 100));
      };
      r.onload = () => {
        onProgress(100);
        const s = r.result as string;
        resolve(s.split(",")[1] || "");
      };
      r.onerror = () => reject(new Error("Lecture du fichier échouée"));
      r.readAsDataURL(f);
    });

  const submit = async () => {
    if (!title.trim()) return toast.error("Ajoute un titre");
    if (plan !== "premium" && credits < 5) {
      toast.error("Crédits insuffisants", {
        description: "Il vous faut au moins 5 crédits pour générer un résumé ou un quiz.",
        action: { label: "Passer au Premium", onClick: () => onQuotaExceeded() },
      });
      return;
    }
    setErrorMsg(null);
    try {
      let payload: any = { title, subject, sourceType: "text" as const };
      if (tab === "text") {
        if (text.trim().length < 40) return toast.error("Le texte est trop court");
        payload = { ...payload, sourceType: "text", text };
        setPhase("processing");
      } else {
        if (!file) return toast.error("Choisis un fichier");
        setPhase("uploading");
        setProgress(0);
        const base64 = await fileToBase64(file, setProgress);
        const mime = file.type;
        const isAudioVideo = mime.startsWith("audio/") || mime.startsWith("video/");
        const isPdf = mime === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");
        const isWord = /wordprocessingml|msword/.test(mime) || /\.docx?$/i.test(file.name);
        const sourceType = isAudioVideo ? (mime.startsWith("video/") ? "video" : "audio") : isPdf ? "pdf" : isWord ? "word" : "text";
        payload = { ...payload, sourceType, fileBase64: base64, fileMime: mime, fileName: file.name };
        setPhase("processing");
      }
      const { courseId } = await create({ data: payload });
      toast.success("Cours généré !");
      onDone();
      navigate({ to: "/course/$id", params: { id: courseId } });
    } catch (e: any) {
      const msg = e?.message ?? "Échec de la génération";
      if (/quota|crédit/i.test(msg)) {
        toast.error(msg, {
          description: "Passe au Premium pour continuer sans limite.",
          action: { label: "Passer au Premium", onClick: () => onQuotaExceeded() },
        });
        setPhase("idle");
      } else {
        setErrorMsg(msg);
        setPhase("error");
      }
    }
  };

  const busy = phase === "uploading" || phase === "processing";

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <Card className="w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold">Nouveau cours</h3>
          <p className="mt-1 text-sm text-muted-foreground">Choisis une source, EduNote fera le reste.</p>
          <div className="mt-4 grid gap-3">
            <div>
              <Label>Titre</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Chapitre 3 — La photosynthèse" className="mt-1" />
            </div>
            <div>
              <Label>Matière (optionnel)</Label>
              <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="SVT" className="mt-1" />
            </div>
          </div>

          <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="mt-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="text"><Type className="h-4 w-4" /> Texte</TabsTrigger>
              <TabsTrigger value="file"><FileText className="h-4 w-4" /> Fichier</TabsTrigger>
            </TabsList>
            <TabsContent value="text" className="mt-3">
              <Textarea rows={8} value={text} onChange={(e) => setText(e.target.value)} placeholder="Colle ici le texte de ton cours…" />
            </TabsContent>
            <TabsContent value="file" className="mt-3">
              <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground hover:border-primary/50">
                <Mic className="h-5 w-5" />
                {file ? <span className="font-medium text-foreground">{file.name}</span> : "Glisse un PDF, Word, audio (MP3) ou vidéo (MP4)"}
                <input type="file" className="hidden" accept=".pdf,.doc,.docx,audio/*,video/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
              </label>
            </TabsContent>
          </Tabs>

          {phase === "uploading" && (
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Téléchargement du fichier…</span>
                <span className="tabular-nums text-muted-foreground">{progress}%</span>
              </div>
              <Progress value={progress} />
            </div>
          )}
          {phase === "processing" && (
            <div className="mt-4 space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Sparkles className="h-4 w-4 animate-pulse text-primary" />
                <span>Génération du résumé par l'IA en cours, veuillez patienter… ✨</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                <div className="h-full w-1/3 rounded-full bg-primary animate-[slide-in-right_1.4s_ease-in-out_infinite]" />
              </div>
            </div>
          )}
          {phase === "error" && (
            <div className="mt-4 space-y-1 rounded-lg border border-destructive/40 bg-destructive/5 p-3 text-sm">
              <p className="font-medium text-destructive">Échec de la génération</p>
              <p className="text-muted-foreground">{errorMsg}</p>
            </div>
          )}

          <div className="mt-5 flex justify-end gap-2">
            <Button variant="ghost" onClick={onClose} disabled={busy}>Annuler</Button>
            {phase === "error" ? (
              <Button onClick={submit}>Réessayer</Button>
            ) : (
              <Button onClick={submit} disabled={busy}>Générer</Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function ReferralCard({ code }: { code: string }) {
  const link = `https://edunote-app.lovable.app/auth?ref=${code}`;
  const copy = () => {
    navigator.clipboard.writeText(link).then(
      () => toast.success("Lien copié !"),
      () => toast.error("Impossible de copier"),
    );
  };
  return (
    <Card className="mt-6">
      <CardContent className="p-5">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <Gift className="h-4 w-4 text-primary" /> Parrainage
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          Partage ton lien et gagne <strong>25 crédits</strong> par filleul. Ton ami démarre avec <strong>25 crédits</strong>.
        </p>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <Input readOnly value={link} className="font-mono text-xs" onFocus={(e) => e.currentTarget.select()} />
          <Button onClick={copy} variant="outline" className="shrink-0">
            <Copy className="h-4 w-4" /> Copier le lien
          </Button>
        </div>
        <div className="mt-3 text-xs text-muted-foreground">Ton code : <span className="font-mono font-semibold text-foreground">{code}</span></div>
        <div className="mt-3">
          <Link to="/referral" className="text-xs font-medium text-primary hover:underline">Voir le tableau de bord parrainage →</Link>
        </div>
      </CardContent>
    </Card>
  );
}

function UpgradeDialog({ onClose, onActivated }: { onClose: () => void; onActivated: () => void }) {
  const redeem = useServerFn(redeemLicenseKey);
  const [key, setKey] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!key.trim()) return toast.error("Saisis ta clé de licence");
    setLoading(true);
    try {
      await redeem({ data: { key } });
      toast.success("Premium activé ! Bienvenue 🎉");
      onActivated();
    } catch (e: any) {
      toast.error(e?.message ?? "Clé invalide");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <Card className="w-full max-w-md" onClick={(e) => e.stopPropagation()}>
        <CardContent className="p-6">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold">Passer au Premium</h3>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            Achète une clé de licence sur MyChariow, puis colle-la ci-dessous pour débloquer l'accès illimité.
          </p>

          <a href={MYCHARIOW_URL} target="_blank" rel="noopener noreferrer" className="mt-5 block">
            <Button className="w-full" size="lg">Acheter une clé sur MyChariow</Button>
          </a>

          <div className="mt-6 space-y-2">
            <Label htmlFor="license-key">Saisir votre clé de licence</Label>
            <Input
              id="license-key"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="EDUNOTE-XXXX-XXXX"
              autoComplete="off"
              disabled={loading}
            />
            <Button onClick={submit} disabled={loading} className="w-full" variant="secondary">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Valider la clé"}
            </Button>
          </div>

          <div className="mt-5 flex justify-end">
            <Button variant="ghost" onClick={onClose} disabled={loading}>Fermer</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}