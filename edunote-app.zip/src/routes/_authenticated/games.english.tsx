import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { generateGameQuestions } from "@/lib/games.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { ArrowLeft, Languages, Play, RotateCw, Trophy, CheckCircle2, XCircle, BookOpen, Loader2 } from "lucide-react";
import { saveScore } from "@/components/leaderboard";

export const Route = createFileRoute("/_authenticated/games/english")({
  head: () => ({ meta: [{ title: "Word Master — EduNote" }] }),
  component: WordMaster,
});

type EngQ = {
  kind: "fill" | "vocab";
  question: string;
  options: string[];
  answer: string;
  rule: string;
};

// Banks — kept concise & correct
const FILL_BANK: EngQ[] = [
  { kind: "fill", question: "She ___ to school every day.", options: ["go", "goes", "going", "gone"], answer: "goes",
    rule: "Au présent simple, à la 3ᵉ personne du singulier (he/she/it), on ajoute -s au verbe." },
  { kind: "fill", question: "I ___ never been to Paris.", options: ["has", "am", "have", "had"], answer: "have",
    rule: "Present perfect : « I / you / we / they » utilisent 'have' + participe passé." },
  { kind: "fill", question: "They ___ playing football when it started to rain.", options: ["was", "were", "are", "is"], answer: "were",
    rule: "Past continuous : sujet pluriel → 'were' + verbe-ing." },
  { kind: "fill", question: "If I ___ rich, I would travel the world.", options: ["am", "was", "were", "be"], answer: "were",
    rule: "Conditionnel de type 2 : 'if' + prétérit ('were' pour toutes les personnes) + 'would'." },
  { kind: "fill", question: "The book is ___ the table.", options: ["in", "on", "at", "under"], answer: "on",
    rule: "'On' = posé sur une surface horizontale." },
  { kind: "fill", question: "We arrived ___ the airport at 8 pm.", options: ["in", "on", "to", "at"], answer: "at",
    rule: "'Arrive at' pour un lieu précis (aéroport, gare) ; 'arrive in' pour une ville/pays." },
  { kind: "fill", question: "He has been working here ___ 2015.", options: ["for", "since", "from", "during"], answer: "since",
    rule: "'Since' + point de départ dans le temps ; 'for' + durée." },
  { kind: "fill", question: "I'm afraid ___ spiders.", options: ["of", "from", "by", "with"], answer: "of",
    rule: "'Afraid of' est la préposition fixe pour exprimer la peur." },
  { kind: "fill", question: "She ___ her homework yet.", options: ["didn't finish", "hasn't finished", "doesn't finish", "isn't finishing"], answer: "hasn't finished",
    rule: "'Yet' s'utilise avec le present perfect à la forme négative." },
  { kind: "fill", question: "This is the man ___ car was stolen.", options: ["who", "which", "whose", "that"], answer: "whose",
    rule: "'Whose' est le pronom relatif de possession." },
  { kind: "fill", question: "If it ___ tomorrow, we will stay home.", options: ["rain", "rains", "rained", "will rain"], answer: "rains",
    rule: "Conditionnel de type 1 : 'if' + présent simple, résultat en 'will' + base." },
  { kind: "fill", question: "There ___ many people at the concert.", options: ["was", "were", "is", "be"], answer: "were",
    rule: "'There + be' s'accorde avec le sujet qui suit : 'people' est pluriel → 'were'." },
];

const VOCAB_BANK: { fr: string; en: string }[] = [
  { fr: "chien", en: "dog" }, { fr: "chat", en: "cat" }, { fr: "livre", en: "book" },
  { fr: "voiture", en: "car" }, { fr: "maison", en: "house" }, { fr: "arbre", en: "tree" },
  { fr: "eau", en: "water" }, { fr: "pain", en: "bread" }, { fr: "fenêtre", en: "window" },
  { fr: "école", en: "school" }, { fr: "professeur", en: "teacher" }, { fr: "élève", en: "student" },
  { fr: "matin", en: "morning" }, { fr: "soir", en: "evening" }, { fr: "hier", en: "yesterday" },
  { fr: "demain", en: "tomorrow" }, { fr: "toujours", en: "always" }, { fr: "jamais", en: "never" },
  { fr: "bonheur", en: "happiness" }, { fr: "tristesse", en: "sadness" }, { fr: "rapide", en: "fast" },
  { fr: "lent", en: "slow" }, { fr: "difficile", en: "difficult" }, { fr: "facile", en: "easy" },
  { fr: "acheter", en: "buy" }, { fr: "vendre", en: "sell" }, { fr: "manger", en: "eat" },
  { fr: "boire", en: "drink" }, { fr: "travailler", en: "work" }, { fr: "dormir", en: "sleep" },
];

const TOTAL = 10;

function shuffle<T>(a: T[]): T[] { return [...a].sort(() => Math.random() - 0.5); }

function makeVocabQ(): EngQ {
  const dir = Math.random() < 0.5 ? "fr-en" : "en-fr";
  const item = VOCAB_BANK[Math.floor(Math.random() * VOCAB_BANK.length)];
  const distractors = shuffle(VOCAB_BANK.filter((v) => v !== item)).slice(0, 3);
  if (dir === "fr-en") {
    const options = shuffle([item.en, ...distractors.map((d) => d.en)]);
    return { kind: "vocab", question: `Traduis en anglais : « ${item.fr} »`, options, answer: item.en,
      rule: `« ${item.fr} » se traduit par « ${item.en} ».` };
  }
  const options = shuffle([item.fr, ...distractors.map((d) => d.fr)]);
  return { kind: "vocab", question: `Traduis en français : "${item.en}"`, options, answer: item.fr,
    rule: `"${item.en}" se traduit par « ${item.fr} ».` };
}

function buildRound(): EngQ[] {
  const list: EngQ[] = [];
  const fills = shuffle(FILL_BANK);
  let fi = 0;
  for (let i = 0; i < TOTAL; i++) {
    if (i % 2 === 0 && fi < fills.length) list.push(fills[fi++]);
    else list.push(makeVocabQ());
  }
  // shuffle options for fill items too
  return list.map((q) => ({ ...q, options: shuffle(q.options) }));
}

function WordMaster() {
  const [phase, setPhase] = useState<"select" | "playing" | "finished">("select");
  const [questions, setQuestions] = useState<EngQ[]>([]);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [answers, setAnswers] = useState<{ q: EngQ; user: string | null; ok: boolean }[]>([]);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);
  const genQuestions = useServerFn(generateGameQuestions);

  const start = async () => {
    setLoading(true);
    let list: EngQ[] = [];
    try {
      const res = await genQuestions({ data: { game: "english", count: TOTAL } });
      list = (res?.questions ?? [])
        .filter((q: any) => q && typeof q.q === "string" && Array.isArray(q.options) && q.options.length === 4 && q.options.includes(q.answer))
        .map((q: any) => ({
          kind: q.kind === "vocab" ? "vocab" : "fill",
          question: q.q as string,
          options: shuffle(q.options as string[]),
          answer: q.answer as string,
          rule: (q.explanation as string) ?? "",
        }));
    } catch {
      toast.message("Questions hors-ligne", { description: "IA indisponible, banque locale utilisée." });
    }
    if (list.length < 5) list = buildRound();
    setLoading(false);
    setQuestions(list.slice(0, TOTAL));
    setIdx(0); setScore(0); setSelected(null); setAnswers([]); setSaved(false);
    setPhase("playing");
  };

  const current = questions[idx];
  const progressPct = ((idx + 1) / questions.length) * 100;

  const pick = (opt: string) => {
    if (selected) return;
    const ok = opt === current.answer;
    setSelected(opt);
    if (ok) setScore((s) => s + 100);
    setAnswers((a) => [...a, { q: current, user: opt, ok }]);
  };

  const next = async () => {
    if (idx + 1 >= questions.length) {
      setPhase("finished");
      if (!saved) {
        try {
          await saveScore({ score, matiere: "Anglais" });
          setSaved(true);
        } catch (e: any) { toast.error(e?.message ?? "Erreur d'enregistrement"); }
      }
      return;
    }
    setIdx((i) => i + 1);
    setSelected(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-amber-500/5 text-foreground">
      <header className="border-b border-border/60 bg-background/70 backdrop-blur">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-4 py-3 sm:px-6 sm:py-4">
          <Link to="/games" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Jeux
          </Link>
          <div className="flex items-center gap-2">
            <Languages className="h-5 w-5 text-amber-500" />
            <span className="font-semibold">Word Master</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 py-6 sm:px-6 sm:py-10">
        {phase === "select" && (
          <Card className="border-amber-500/30">
            <CardContent className="space-y-5 p-6">
              <div>
                <h1 className="text-xl font-bold">Word Master 🇬🇧</h1>
                <p className="text-sm text-muted-foreground">{TOTAL} questions : alternance <b>phrases à trous</b> & <b>vocabulaire express</b>. Une fiche de correction s'affiche à la fin.</p>
              </div>
              <Button onClick={start} disabled={loading} className="w-full bg-amber-600 text-white hover:bg-amber-700">
                {loading
                  ? <><Loader2 className="mr-1 h-4 w-4 animate-spin" /> Génération IA…</>
                  : <><Play className="mr-1 h-4 w-4" /> Démarrer</>}
              </Button>
            </CardContent>
          </Card>
        )}

        {phase === "playing" && current && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Question {idx + 1} / {questions.length}</span>
              <span className="font-semibold">{score} pts</span>
            </div>
            <Progress value={progressPct} className="h-1.5" />

            <Card className="border-amber-500/30">
              <CardContent className="space-y-5 p-6">
                <Badge variant="outline" className="capitalize">
                  {current.kind === "fill" ? "Phrase à trous" : "Vocabulaire"}
                </Badge>
                <h2 className="text-lg font-semibold sm:text-xl">{current.question}</h2>
                <div className="grid gap-2 sm:grid-cols-2">
                  {current.options.map((opt) => {
                    const isSel = selected === opt;
                    const isRight = opt === current.answer;
                    const show = selected !== null;
                    return (
                      <Button
                        key={opt}
                        variant="outline"
                        disabled={selected !== null}
                        onClick={() => pick(opt)}
                        className={`h-auto justify-start whitespace-normal p-4 text-left ${
                          show && isRight ? "border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : ""
                        } ${show && isSel && !isRight ? "border-red-500 bg-red-500/10 text-red-700 dark:text-red-300" : ""}`}
                      >
                        {opt}
                      </Button>
                    );
                  })}
                </div>

                {selected && (
                  <div className="rounded-lg border border-border/60 bg-muted/30 p-3 text-sm">
                    {selected === current.answer ? (
                      <span className="font-medium text-emerald-600 dark:text-emerald-400">✅ Bien joué ! +100 pts</span>
                    ) : (
                      <span className="font-medium text-red-600 dark:text-red-400">
                        ❌ Réponse : <b>{current.answer}</b>
                      </span>
                    )}
                  </div>
                )}

                {selected && (
                  <Button onClick={next} className="w-full">
                    {idx + 1 >= questions.length ? "Voir la correction" : "Question suivante"}
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {phase === "finished" && (
          <div className="space-y-5">
            <Card className="border-amber-500/40 bg-gradient-to-br from-amber-500/5 to-rose-500/5">
              <CardContent className="space-y-3 p-8 text-center">
                <Trophy className="mx-auto h-14 w-14 text-amber-500 animate-bounce" />
                <div className="text-sm text-muted-foreground">Partie terminée</div>
                <div className="text-5xl font-black tracking-tight">{score}</div>
                <div className="text-sm text-muted-foreground">{answers.filter((a) => a.ok).length} / {answers.length} bonnes réponses</div>
                {saved && <Badge variant="secondary">Score enregistré au classement</Badge>}
                <div className="flex flex-wrap justify-center gap-2 pt-2">
                  <Button onClick={start} variant="outline"><RotateCw className="mr-1 h-4 w-4" /> Rejouer</Button>
                  <Link to="/games"><Button>Autres jeux</Button></Link>
                </div>
              </CardContent>
            </Card>

            <div>
              <div className="mb-3 flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-amber-500" />
                <h2 className="text-lg font-semibold">Fiche de correction</h2>
              </div>
              <div className="space-y-2">
                {answers.map((a, i) => (
                  <Card key={i} className={a.ok ? "border-emerald-500/30" : "border-red-500/30"}>
                    <CardContent className="space-y-2 p-4 text-sm">
                      <div className="flex items-start gap-2">
                        {a.ok ? <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-500" /> : <XCircle className="mt-0.5 h-4 w-4 text-red-500" />}
                        <div className="font-medium">{a.q.question}</div>
                      </div>
                      <div className="pl-6 text-xs text-muted-foreground">
                        Ta réponse : <span className={a.ok ? "text-emerald-600" : "text-red-600 line-through"}>{a.user ?? "—"}</span>
                        {!a.ok && <> · Bonne réponse : <b className="text-emerald-600">{a.q.answer}</b></>}
                      </div>
                      <div className="pl-6 text-xs italic text-muted-foreground">💡 {a.q.rule}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}