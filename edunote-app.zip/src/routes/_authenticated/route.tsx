import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { BottomNav } from "@/components/bottom-nav";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    try {
      const { data, error } = await supabase.auth.getUser();
      if (!error && data.user) return { user: data.user };
    } catch {
      // A short network interruption must not crash the entire app. The
      // persisted session keeps already authenticated users in offline mode;
      // protected server calls still validate the token independently.
      const { data } = await supabase.auth.getSession();
      if (data.session?.user) return { user: data.session.user };
    }
    throw redirect({ to: "/auth" });
  },
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  return (
    <div className="pb-20">
      <Outlet />
      <BottomNav />
    </div>
  );
}