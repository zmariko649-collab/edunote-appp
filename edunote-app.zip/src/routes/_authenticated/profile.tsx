import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getMySession } from "@/lib/admin.functions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { FileText, Trophy, Coins, Flame, Gift, KeyRound, Shield, LogOut, Copy, Share2, ChevronRight, Sparkles } from "lucide-react";

const WHATSAPP_CHANNEL_URL = "https://whatsapp.com/channel/0029VbD4MGs0VycB9SBKuA2s";

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.174.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12.05 21.785h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.999-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.886 9.884zm8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
    </svg>
  );
}

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [{ title: "Profil — EduNote" }] }),
  component: ProfilePage,
});

type P = { full_name: string | null; email: string | null; plan: string; credits: number; referral_code: string | null };

function ProfilePage() {
  const navigate = useNavigate();
  const fetchSession = useServerFn(getMySession);
  const [profile, setProfile] = useState<P | null>(null);
  const [role, setRole] = useState<"user" | "moderator" | "admin">("user");
  const [docs, setDocs] = useState(0);
  const [quizWins, setQuizWins] = useState(0);
  const [streak, setStreak] = useState(0);
  const [activeDays, setActiveDays] = useState<Set<number>>(new Set());

  useEffect(() => {
    (async () => {
      try { const s = await fetchSession(); setRole(s.role); } catch {}
      const { data: u } = await supabase.auth.getUser();
      const uid = u.user?.id;
      const [{ data: p }, { data: courses }, { data: attempts }] = await Promise.all([
        supabase.from("profiles").select("full_name, email, plan, credits, referral_code").maybeSingle(),
        supabase.from("courses").select("id, created_at"),
        supabase.from("quiz_attempts").select("is_correct, answered_at").eq("user_id", uid ?? ""),
      ]);
      setProfile(p as P | null);
      setDocs(courses?.length ?? 0);
      setQuizWins((attempts ?? []).filter((a: any) => a.is_correct).length);

      const now = new Date();
      const monday = new Date(now);
      const day = (now.getDay() + 6) % 7;
      monday.setHours(0,0,0,0);
      monday.setDate(now.getDate() - day);
      const ad = new Set<number>();
      const dates = [
        ...(courses ?? []).map((c: any) => c.created_at),
        ...((attempts ?? []) as any[]).map(a => a.answered_at),
      ];
      for (const iso of dates) {
        const d = new Date(iso);
        if (d >= monday) ad.add((d.getDay() + 6) % 7);
      }
      setActiveDays(ad);

      const daysSet = new Set(dates.map(iso => new Date(iso).toDateString()));
      let st = 0;
      const cur = new Date(); cur.setHours(0,0,0,0);
      while (daysSet.has(cur.toDateString())) { st++; cur.setDate(cur.getDate() - 1); }
      setStreak(st);
    })();
  }, []);

  const signOut = async () => { await supabase.auth.signOut(); navigate({ to: "/" }); };

  const link = profile?.referral_code ? `https://edunote-app.lovable.app/auth?ref=${profile.referral_code}` : "";
  const shareMessage = link
    ? `🚀 Réussis tes examens avec EduNote !\n\nJ'utilise cette application incroyable pour résumer mes cours en quelques secondes, générer des quiz automatiques et même jouer pour réviser mes maths et mon anglais.\n\nViens me rejoindre pour booster tes notes et gagner des crédits gratuits avec mon lien : ${link}`
    : "";
  const copyLink = () => { if (link) navigator.clipboard.writeText(link).then(() => toast.success("Lien copié !"), () => toast.error("Impossible de copier")); };
  const shareWa = () => {
    if (!shareMessage) return;
    const url = `https://wa.me/?text=${encodeURIComponent(shareMessage)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const initial = (profile?.full_name || profile?.email || "?").charAt(0).toUpperCase();
  const isPremium = profile?.plan === "premium";

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 via-background to-background">
      <main className="mx-auto max-w-3xl space-y-5 px-4 py-6 sm:px-6 sm:py-8">
        {/* Header user card */}
        <Card className="overflow-hidden rounded-3xl border-none bg-gradient-to-br from-primary via-primary to-fuchsia-600 text-primary-foreground shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="grid h-16 w-16 shrink-0 place-items-center rounded-full bg-white/20 text-2xl font-bold backdrop-blur">
                {initial}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-lg font-bold">{profile?.full_name || "Étudiant"}</div>
                <div className="truncate text-sm text-white/85">{profile?.email || "—"}</div>
                <div className="mt-2 flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-1 text-xs font-semibold backdrop-blur">
                    {isPremium ? <><Sparkles className="h-3 w-3" /> Premium</> : "Offre Gratuite"}
                  </span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-1 text-xs font-semibold backdrop-blur">
                    <Coins className="h-3 w-3" /> {profile?.credits ?? 0} crédits
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 3 mini counter cards */}
        {profile === null ? (
          <div className="grid grid-cols-3 gap-3">{[0,1,2].map(i => <Skeleton key={i} className="h-24 rounded-2xl" />)}</div>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            <MiniStat icon={<FileText className="h-4 w-4" />} color="text-sky-600" label="Documents" value={docs} />
            <MiniStat icon={<Trophy className="h-4 w-4" />} color="text-emerald-600" label="Quiz réussis" value={quizWins} />
            <MiniStat icon={<Coins className="h-4 w-4" />} color="text-amber-600" label="Crédits" value={profile.credits} />
          </div>
        )}

        {/* Streak */}
        <Card className="rounded-2xl border-amber-500/40 bg-gradient-to-br from-orange-500/10 to-amber-500/10">
          <CardContent className="flex items-center gap-3 p-5">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-orange-500 to-amber-500 text-white shadow">
              <Flame className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="font-semibold">🔥 {streak} jour{streak > 1 ? "s" : ""} de suite !</div>
              <div className="text-xs text-muted-foreground">Continue comme ça, ta régularité paie.</div>
            </div>
          </CardContent>
        </Card>

        {/* Weekly activity */}
        <Card className="rounded-2xl">
          <CardContent className="p-5">
            <div className="text-sm font-semibold">Activité cette semaine</div>
            <div className="mt-3 flex items-center justify-between gap-1">
              {["L","M","M","J","V","S","D"].map((d, i) => {
                const active = activeDays.has(i);
                return (
                  <div key={i} className="flex flex-1 flex-col items-center gap-1.5">
                    <div className={`grid h-9 w-9 place-items-center rounded-full text-xs font-bold ${active ? "bg-primary text-primary-foreground shadow" : "bg-muted text-muted-foreground"}`}>
                      {active ? "✓" : d}
                    </div>
                    <span className="text-[10px] text-muted-foreground">{d}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Referral */}
        <Card className="overflow-hidden rounded-3xl border-none bg-gradient-to-br from-fuchsia-600 via-purple-600 to-indigo-600 text-white shadow-xl">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white/20 backdrop-blur">
                <Gift className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <div className="font-bold">🎁 Invite un ami</div>
                <div className="text-xs text-white/85">Gagne <strong>25 crédits</strong> par filleul.</div>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button onClick={copyLink} disabled={!link} className="flex items-center justify-center gap-2 rounded-2xl bg-white/15 px-3 py-2.5 text-sm font-semibold backdrop-blur transition hover:bg-white/25 disabled:opacity-50">
                <Copy className="h-4 w-4" /> Copier mon lien
              </button>
              <button onClick={shareWa} disabled={!link} className="flex items-center justify-center gap-2 rounded-2xl bg-white text-purple-700 px-3 py-2.5 text-sm font-semibold shadow transition hover:bg-white/90 disabled:opacity-50">
                <Share2 className="h-4 w-4" /> WhatsApp
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Menu list */}
        <Card className="overflow-hidden rounded-2xl">
          <div className="divide-y divide-border/60">
            <MenuLink to="/settings" icon={<KeyRound className="h-4 w-4" />} label="Licence & compte" hint={isPremium ? <Badge>Premium</Badge> : null} />
            <MenuLink to="/referral" icon={<Gift className="h-4 w-4" />} label="Programme de parrainage" />
            {role === "admin" && (
              <MenuLink to="/admin" icon={<Shield className="h-4 w-4" />} label="Espace Admin" hint={<Badge variant="secondary">Admin</Badge>} />
            )}
            <MenuExternal href={WHATSAPP_CHANNEL_URL} icon={<WhatsAppIcon className="h-4 w-4 text-green-600" />} label="Support WhatsApp" />
            <button onClick={signOut} className="flex w-full items-center gap-3 px-5 py-4 text-sm text-destructive hover:bg-destructive/5">
              <LogOut className="h-4 w-4" /> Se déconnecter
            </button>
          </div>
        </Card>

        {!isPremium && (
          <Button onClick={() => navigate({ to: "/settings" })} size="lg" className="w-full rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:opacity-90">
            <Sparkles className="h-4 w-4" /> Passer au Premium
          </Button>
        )}
      </main>
    </div>
  );
}

function MiniStat({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number | string; color: string }) {
  return (
    <Card className="rounded-2xl border-border/60">
      <CardContent className="p-3.5">
        <div className={`inline-flex rounded-lg bg-muted p-1.5 ${color}`}>{icon}</div>
        <div className="mt-2 text-xl font-bold leading-tight">{value}</div>
        <div className="text-[11px] text-muted-foreground">{label}</div>
      </CardContent>
    </Card>
  );
}

function MenuLink({ to, icon, label, hint }: { to: string; icon: React.ReactNode; label: string; hint?: React.ReactNode }) {
  return (
    <Link to={to} className="flex items-center gap-3 px-5 py-4 text-sm transition hover:bg-accent/60">
      <span className="text-muted-foreground">{icon}</span>
      <span className="flex-1 font-medium">{label}</span>
      {hint}
      <ChevronRight className="h-4 w-4 text-muted-foreground" />
    </Link>
  );
}

function MenuExternal({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 px-5 py-4 text-sm transition hover:bg-accent/60">
      <span>{icon}</span>
      <span className="flex-1 font-medium">{label}</span>
      <ChevronRight className="h-4 w-4 text-muted-foreground" />
    </a>
  );
}