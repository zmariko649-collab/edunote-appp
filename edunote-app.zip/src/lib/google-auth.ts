import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { isNativeApp } from "@/lib/native";

export type GoogleSignInResult = {
  error?: { message: string };
  /** true = le navigateur part vers Google, la suite se passe au retour. */
  redirected?: boolean;
};

let nativeInitialized = false;

async function loadNativeGoogleAuth() {
  const mod = await import("@codetrix-studio/capacitor-google-auth");
  const GoogleAuth = mod.GoogleAuth;
  if (!nativeInitialized) {
    // Les options viennent de capacitor.config.ts (plugins.GoogleAuth).
    await GoogleAuth.initialize();
    nativeInitialized = true;
  }
  return GoogleAuth;
}

/**
 * Connexion Google unifiée.
 * - Dans le conteneur Capacitor : volet natif Android (liste des comptes du téléphone).
 * - Sur le web : flux OAuth Lovable/Supabase classique.
 */
export async function signInWithGoogle(redirectUri: string): Promise<GoogleSignInResult> {
  if (isNativeApp()) {
    try {
      const GoogleAuth = await loadNativeGoogleAuth();
      const user = await GoogleAuth.signIn();
      const idToken = user?.authentication?.idToken;
      if (!idToken) {
        return { error: { message: "Google n'a pas renvoyé de jeton d'identité." } };
      }
      const { error } = await supabase.auth.signInWithIdToken({
        provider: "google",
        token: idToken,
      });
      if (error) return { error: { message: error.message } };
      return { redirected: false };
    } catch (err: any) {
      const msg = String(err?.message ?? err ?? "");
      if (/cancel/i.test(msg) || err?.code === "12501") {
        return { error: { message: "Connexion Google annulée." } };
      }
      return { error: { message: msg || "Échec de la connexion Google native." } };
    }
  }

  const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: redirectUri });
  return { error: result.error ? { message: result.error.message } : undefined, redirected: result.redirected };
}

export async function signOutGoogleNative() {
  if (!isNativeApp()) return;
  try {
    const GoogleAuth = await loadNativeGoogleAuth();
    await GoogleAuth.signOut();
  } catch {
    // pas bloquant
  }
}
