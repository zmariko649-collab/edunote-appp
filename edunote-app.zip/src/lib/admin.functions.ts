import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (error) throw new Error("Erreur d'autorisation");
  if (!data) throw new Error("Accès refusé");
}

export const getMySession = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: profile } = await supabase
      .from("profiles")
      .select("is_banned, email, full_name, plan")
      .eq("user_id", userId)
      .maybeSingle();
    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    const roleList = (roles ?? []).map((r: any) => r.role as string);
    const role: "admin" | "moderator" | "user" = roleList.includes("admin")
      ? "admin"
      : roleList.includes("moderator")
      ? "moderator"
      : "user";
    return {
      userId,
      isBanned: !!profile?.is_banned,
      role,
      email: profile?.email ?? null,
      fullName: profile?.full_name ?? null,
      plan: profile?.plan ?? "free",
    };
  });

export const listAllUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: profiles, error } = await supabaseAdmin
      .from("profiles")
      .select("user_id, email, full_name, plan, is_banned, created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    const { data: roles } = await supabaseAdmin.from("user_roles").select("user_id, role");
    const rolesByUser = new Map<string, string[]>();
    for (const r of roles ?? []) {
      const list = rolesByUser.get((r as any).user_id) ?? [];
      list.push((r as any).role);
      rolesByUser.set((r as any).user_id, list);
    }
    return (profiles ?? []).map((p: any) => {
      const rs = rolesByUser.get(p.user_id) ?? [];
      const role = rs.includes("admin") ? "admin" : rs.includes("moderator") ? "moderator" : "user";
      return { ...p, role };
    });
  });

export const setUserBanned = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { userId: string; banned: boolean }) => {
    if (!i?.userId || typeof i.banned !== "boolean") throw new Error("Paramètres invalides");
    return i;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    if (data.userId === context.userId) throw new Error("Tu ne peux pas te bannir toi-même.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ is_banned: data.banned })
      .eq("user_id", data.userId);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const setUserRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { userId: string; role: "user" | "moderator" | "admin" }) => {
    if (!i?.userId || !["user", "moderator", "admin"].includes(i.role)) throw new Error("Paramètres invalides");
    return i;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Remplace le rôle : supprime moderator/admin puis insère le nouveau (garde 'user' comme rôle de base)
    await supabaseAdmin
      .from("user_roles")
      .delete()
      .eq("user_id", data.userId)
      .in("role", ["moderator", "admin"]);
    if (data.role !== "user") {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .insert({ user_id: data.userId, role: data.role });
      if (error && !error.message.includes("duplicate")) throw new Error(error.message);
    }
    return { ok: true as const };
  });

function randomCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const block = () =>
    Array.from({ length: 4 }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join("");
  return `EDUNOTE-${block()}-${block()}`;
}

export const generateLicence = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    for (let attempt = 0; attempt < 5; attempt++) {
      const code = randomCode();
      const { data, error } = await supabaseAdmin
        .from("licences")
        .insert({ code, status: "unused" })
        .select("id, code, status, created_at, used_by, used_at")
        .single();
      if (!error) return data;
      if (!String(error.message).toLowerCase().includes("duplicate")) throw new Error(error.message);
    }
    throw new Error("Impossible de générer une clé unique, réessaye.");
  });

export const listLicences = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("licences")
      .select("id, code, status, created_at, used_by, used_at")
      .order("created_at", { ascending: false })
      .limit(500);
    if (error) throw new Error(error.message);
    return data ?? [];
  });