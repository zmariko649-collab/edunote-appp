// Détection d'environnement : navigateur classique vs conteneur Capacitor (Android/iOS).
export function isNativeApp(): boolean {
  if (typeof window === "undefined") return false;
  const cap = (window as any).Capacitor;
  return Boolean(cap?.isNativePlatform?.());
}

export function nativePlatform(): "android" | "ios" | "web" {
  if (typeof window === "undefined") return "web";
  const p = (window as any).Capacitor?.getPlatform?.();
  return p === "android" || p === "ios" ? p : "web";
}
