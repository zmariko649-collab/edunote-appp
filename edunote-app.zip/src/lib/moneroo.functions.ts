import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { getRequestHost } from "@tanstack/react-start/server";

const PREMIUM_AMOUNT = 2000;
const PREMIUM_CURRENCY = "XOF";
const MONEROO_API = "https://api.moneroo.io/v1";

export const createMonerooPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const secret = process.env.MONEROO_SECRET_KEY;
    if (!secret) throw new Error("Clé Moneroo non configurée");

    const { data: profile } = await supabase.from("profiles").select("email, full_name").eq("user_id", userId).maybeSingle();
    const email = profile?.email ?? "client@example.com";
    const fullName = (profile?.full_name ?? "Étudiant Étudiant").trim();
    const [first, ...rest] = fullName.split(" ");
    const firstName = first || "Étudiant";
    const lastName = rest.join(" ") || "Étudiant";

    const host = getRequestHost();
    const returnUrl = `https://${host}/dashboard?payment=success`;

    const res = await fetch(`${MONEROO_API}/payments/initialize`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${secret}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        amount: PREMIUM_AMOUNT,
        currency: PREMIUM_CURRENCY,
        description: "Abonnement EduNote Premium (1 mois)",
        customer: { email, first_name: firstName, last_name: lastName },
        return_url: returnUrl,
        metadata: { user_id: userId },
      }),
    });
    const json: any = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(json?.message || `Erreur Moneroo ${res.status}`);
    }
    const paymentId = json?.data?.id ?? json?.data?.payment_id;
    const checkoutUrl = json?.data?.checkout_url;
    if (!checkoutUrl || !paymentId) throw new Error("Réponse Moneroo invalide");

    await supabase.from("payments").insert({
      user_id: userId,
      moneroo_payment_id: paymentId,
      amount: PREMIUM_AMOUNT,
      currency: PREMIUM_CURRENCY,
      status: "PENDING",
    });

    return { checkoutUrl };
  });