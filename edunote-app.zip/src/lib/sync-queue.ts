// File d'attente hors-ligne : les écritures faites sans réseau sont stockées
// localement puis rejouées automatiquement au retour de la connexion.
import { useEffect, useState } from "react";

export const SYNC_QUEUE_KEY = "edunote_sync_queue";

export type PendingOp = {
  id: string;
  table: string;
  action: "insert" | "update";
  payload: Record<string, unknown>;
  match?: Record<string, unknown>;
  createdAt: string;
};

function read(): PendingOp[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(SYNC_QUEUE_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? (arr as PendingOp[]) : [];
  } catch {
    return [];
  }
}

function write(ops: PendingOp[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(ops.slice(0, 200)));
  } catch {
    // quota dépassé : on ignore
  }
}

export function queueOperation(op: Omit<PendingOp, "id" | "createdAt">) {
  const ops = read();
  ops.push({ ...op, id: crypto.randomUUID(), createdAt: new Date().toISOString() });
  write(ops);
  window.dispatchEvent(new CustomEvent("edunote:queue-changed", { detail: ops.length }));
}

export function pendingCount(): number {
  return read().length;
}

let flushing = false;

/** Rejoue toutes les opérations en attente. Les échecs restent en file. */
export async function flushQueue(): Promise<number> {
  if (flushing || typeof window === "undefined" || !navigator.onLine) return 0;
  const ops = read();
  if (ops.length === 0) return 0;
  flushing = true;
  const { supabase } = await import("@/integrations/supabase/client");
  const remaining: PendingOp[] = [];
  let done = 0;
  try {
    for (const op of ops) {
      try {
        const table = supabase.from(op.table as never) as any;
        const res =
          op.action === "insert"
            ? await table.insert(op.payload)
            : await table.update(op.payload).match(op.match ?? {});
        if (res?.error) remaining.push(op);
        else done += 1;
      } catch {
        remaining.push(op);
      }
    }
  } finally {
    write(remaining);
    flushing = false;
    window.dispatchEvent(new CustomEvent("edunote:queue-changed", { detail: remaining.length }));
  }
  return done;
}

/** Surveille l'état réseau et synchronise dès le retour en ligne. */
export function useNetworkSync() {
  const [online, setOnline] = useState(() =>
    typeof navigator === "undefined" ? true : navigator.onLine,
  );
  const [pending, setPending] = useState(0);

  useEffect(() => {
    setPending(pendingCount());
    const onQueue = (e: Event) => setPending((e as CustomEvent<number>).detail ?? pendingCount());
    const goOnline = () => {
      setOnline(true);
      void flushQueue().then(() => setPending(pendingCount()));
    };
    const goOffline = () => setOnline(false);

    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    window.addEventListener("edunote:queue-changed", onQueue as EventListener);
    if (navigator.onLine) void flushQueue().then(() => setPending(pendingCount()));

    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
      window.removeEventListener("edunote:queue-changed", onQueue as EventListener);
    };
  }, []);

  return { online, pending };
}
