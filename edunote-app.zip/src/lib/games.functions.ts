import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { chatCompletion, extractJson } from "./ai-gateway.server";

const MODEL = "google/gemini-2.5-flash";

type Input = {
  game: "chrono" | "math" | "english";
  subject?: string;
  level?: "facile" | "moyen" | "difficile";
  count?: number;
};

function promptFor(input: Input): { system: string; user: string } {
  const seed = Math.random().toString(36).slice(2, 10);
  const count = Math.max(5, Math.min(input.count ?? 10, 20));

  if (input.game === "chrono") {
    return {
      system:
        "Tu es un générateur de quiz éducatif en français. Réponds UNIQUEMENT avec un JSON valide, sans texte autour, sans balises markdown.",
      user: `Génère ${count} questions de type QCM sur la matière "${input.subject ?? "Culture générale"}", niveau lycée/collège, en français, variées et originales (seed: ${seed}).
Format JSON strict :
{ "questions": [ { "q": "…", "options": ["A","B","C","D"], "answer": "A" } ] }
Contraintes : 4 options distinctes ; "answer" doit être exactement l'une des options ; question concise (max 140 caractères).`,
    };
  }

  if (input.game === "math") {
    const lvl = input.level ?? "moyen";
    return {
      system:
        "Tu es un générateur de défis mathématiques en français. Réponds UNIQUEMENT avec un JSON valide, sans texte autour, sans balises markdown.",
      user: `Génère ${count} défis de calcul mental / algèbre de base, niveau ${lvl}, en français, variés (seed: ${seed}).
Types autorisés : addition, soustraction, multiplication, division entière, priorités opératoires, équation simple ax+b=c, fraction de nombre.
Format JSON strict :
{ "questions": [ { "prompt": "7 × 8", "answer": 56 } ] }
Contraintes : "answer" est un NOMBRE (entier ou décimal). "prompt" est une expression courte à résoudre mentalement. Pas d'unité.`,
    };
  }

  // english
  return {
    system:
      "Tu es un générateur d'exercices d'anglais pour francophones. Réponds UNIQUEMENT avec un JSON valide, sans texte autour, sans balises markdown.",
    user: `Génère ${count} questions d'anglais QCM (4 choix), en alternant deux types (seed: ${seed}) :
- "gap" : phrase anglaise à trou (grammaire, conjugaison, préposition).
- "vocab" : traduction français↔anglais d'un mot.
Format JSON strict :
{ "questions": [ { "kind": "gap"|"vocab", "q": "…", "options": ["A","B","C","D"], "answer": "A", "explanation": "règle ou traduction en français, 1 phrase" } ] }
Contraintes : 4 options distinctes ; "answer" doit être exactement l'une des options ; "explanation" en français, ≤ 140 caractères.`,
  };
}

export const generateGameQuestions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => {
    const i = input as Input;
    if (!i || !["chrono", "math", "english"].includes(i.game)) throw new Error("Invalid game");
    return i;
  })
  .handler(async ({ data }) => {
    const { system, user } = promptFor(data);
    const resp = await chatCompletion({
      model: MODEL,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
      response_format: { type: "json_object" },
      temperature: 1.1,
    });
    const text: string = resp?.choices?.[0]?.message?.content ?? "";
    const parsed = extractJson(text) as { questions?: any[] };
    const questions = Array.isArray(parsed?.questions) ? parsed.questions : [];
    if (questions.length === 0) throw new Error("AI n'a retourné aucune question");
    return { questions };
  });