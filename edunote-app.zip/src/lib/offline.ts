import { useEffect, useState } from "react";

export const OFFLINE_HISTORY_KEY = "edunote_offline_history";

export type OfflineEntry = {
  courseId: string;
  title: string;
  subject?: string | null;
  summary?: string | null;
  keyPoints?: string[] | null;
  flashcards?: { question: string; answer: string }[];
  quizzes?: {
    type: string;
    question: string;
    options: string[] | null;
    correct_answer: string;
    explanation: string | null;
  }[];
  savedAt: string;
};

export function readOfflineHistory(): OfflineEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(OFFLINE_HISTORY_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? (arr as OfflineEntry[]) : [];
  } catch {
    return [];
  }
}

export function saveOfflineEntry(entry: OfflineEntry) {
  if (typeof window === "undefined") return;
  try {
    const list = readOfflineHistory();
    const filtered = list.filter((e) => e.courseId !== entry.courseId);
    filtered.unshift(entry);
    // Cap at 50 pour éviter de saturer le localStorage
    const capped = filtered.slice(0, 50);
    window.localStorage.setItem(OFFLINE_HISTORY_KEY, JSON.stringify(capped));
  } catch {
    // ignore quota errors
  }
}

export function useOnlineStatus(): boolean {
  const [online, setOnline] = useState<boolean>(() =>
    typeof navigator === "undefined" ? true : navigator.onLine,
  );
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  return online;
}