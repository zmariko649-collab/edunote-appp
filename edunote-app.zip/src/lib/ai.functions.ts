import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { chatCompletion, extractJson, transcribeAudio } from "./ai-gateway.server";
import { FREE_LIMITS, currentMonthKey } from "./quotas";

const MODEL = "google/gemini-2.5-flash";

type CreateInput = {
  title: string;
  subject?: string;
  folder?: string;
  sourceType: "text" | "pdf" | "word" | "audio" | "video";
  text?: string;
  fileBase64?: string;
  fileMime?: string;
  fileName?: string;
};

async function ensureQuota(
  supabase: any,
  userId: string,
  field: "summaries_used" | "flashcards_used" | "chat_messages_used" | "quizzes_used",
  limit: number,
) {
  const { data: profile } = await supabase.from("profiles").select("plan").eq("user_id", userId).maybeSingle();
  if (profile?.plan === "premium") return async (inc = 1) => {
    await bumpUsage(supabase, userId, field, inc);
  };
  const month = currentMonthKey();
  const { data: row } = await supabase
    .from("usage_limits")
    .select("*")
    .eq("user_id", userId)
    .eq("month", month)
    .maybeSingle();
  const used = (row?.[field] ?? 0) as number;
  if (used >= limit) {
    throw new Error(`Quota mensuel atteint (${limit}). Passez au plan Premium pour continuer.`);
  }
  return async (inc = 1) => bumpUsage(supabase, userId, field, inc);
}

async function bumpUsage(supabase: any, userId: string, field: string, inc: number) {
  const month = currentMonthKey();
  const { data: existing } = await supabase
    .from("usage_limits")
    .select("id," + field)
    .eq("user_id", userId)
    .eq("month", month)
    .maybeSingle();
  if (existing) {
    await supabase
      .from("usage_limits")
      .update({ [field]: (existing[field] ?? 0) + inc })
      .eq("id", existing.id);
  } else {
    await supabase.from("usage_limits").insert({ user_id: userId, month, [field]: inc });
  }
}

async function extractText(input: CreateInput): Promise<string> {
  if (input.sourceType === "text") {
    return (input.text ?? "").trim();
  }
  if (input.sourceType === "audio" || input.sourceType === "video") {
    if (!input.fileBase64 || !input.fileMime) throw new Error("Fichier audio/vidéo manquant");
    const buf = Uint8Array.from(atob(input.fileBase64), (c) => c.charCodeAt(0));
    const blob = new Blob([buf], { type: input.fileMime });
    return await transcribeAudio(blob, input.fileName ?? "recording");
  }
  if (input.sourceType === "pdf" || input.sourceType === "word") {
    if (!input.fileBase64 || !input.fileMime) throw new Error("Fichier manquant");
    const dataUrl = `data:${input.fileMime};base64,${input.fileBase64}`;
    const resp = await chatCompletion({
      model: MODEL,
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: "Extrais tout le texte lisible de ce document, en français, sans commentaire ni mise en forme markdown. Reproduis fidèlement le contenu." },
            { type: "file", file: { filename: input.fileName ?? "document", file_data: dataUrl } },
          ],
        },
      ],
    });
    return (resp.choices?.[0]?.message?.content ?? "").trim();
  }
  throw new Error("Source non prise en charge");
}

async function generateStructured(rawText: string) {
  const trimmed = rawText.slice(0, 40000);
  const resp = await chatCompletion({
    model: MODEL,
    messages: [
      {
        role: "system",
        content:
          "Tu es un tuteur pédagogique. Toutes tes réponses sont en français, structurées, claires et fidèles au cours fourni. Tu réponds UNIQUEMENT en JSON valide sans texte autour.",
      },
      {
        role: "user",
        content: `À partir du cours ci-dessous, produis un objet JSON avec:\n- title (string, court)\n- summary (string, résumé structuré en markdown avec des sections ## bien organisées, 300-800 mots)\n- key_points (array de 5 à 10 points clés, chaînes courtes)\n- definitions (array de {term, definition})\n- key_dates (array de {date, event}) — vide si non pertinent\n- flashcards (array de 8 à 15 {question, answer})\n- quizzes (array de 5 à 8 {type: "qcm"|"vrai_faux"|"ouverte", question, options (array pour qcm ou vrai_faux), correct_answer, explanation})\n\nCOURS:\n"""\n${trimmed}\n"""`,
      },
    ],
    response_format: { type: "json_object" },
  });
  const content = resp.choices?.[0]?.message?.content ?? "{}";
  return extractJson(content) as {
    title?: string;
    summary: string;
    key_points: string[];
    definitions: { term: string; definition: string }[];
    key_dates: { date: string; event: string }[];
    flashcards: { question: string; answer: string }[];
    quizzes: {
      type: "qcm" | "vrai_faux" | "ouverte";
      question: string;
      options?: string[];
      correct_answer: string;
      explanation?: string;
    }[];
  };
}

export const createCourseFromInput = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: CreateInput) => {
    if (!data?.title?.trim()) throw new Error("Titre requis");
    if (!data?.sourceType) throw new Error("Type source requis");
    return data;
  })
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const bump = await ensureQuota(supabase, userId, "summaries_used", FREE_LIMITS.summaries);

    // Débite 1 crédit pour les comptes gratuits ; illimité en Premium.
    const { data: prof } = await supabase.from("profiles").select("plan").eq("user_id", userId).maybeSingle();
    if (prof?.plan !== "premium") {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { data: row, error: selErr } = await supabaseAdmin
        .from("profiles")
        .select("credits")
        .eq("user_id", userId)
        .maybeSingle();
      if (selErr) throw new Error(selErr.message);
      if (!row || (row.credits ?? 0) < 5) {
        throw new Error("Crédits insuffisants. Il vous faut au moins 5 crédits pour générer un résumé ou un quiz.");
      }
      const { error: decErr } = await supabaseAdmin
        .from("profiles")
        .update({ credits: (row.credits as number) - 5 })
        .eq("user_id", userId)
        .gte("credits", 5);
      if (decErr) throw new Error(decErr.message);
    }

    const rawText = await extractText(data);
    if (!rawText || rawText.length < 40) {
      throw new Error("Contenu trop court ou illisible");
    }
    const generated = await generateStructured(rawText);

    const { data: course, error: cErr } = await supabase
      .from("courses")
      .insert({
        user_id: userId,
        title: data.title.trim() || generated.title || "Cours",
        subject: data.subject?.trim() || null,
        folder: data.folder?.trim() || null,
        source_type: data.sourceType,
        source_url: null,
      })
      .select("id")
      .single();
    if (cErr) throw new Error(cErr.message);

    await supabase.from("transcripts").insert({ course_id: course.id, raw_text: rawText, cleaned_text: rawText });
    await supabase.from("summaries").insert({
      course_id: course.id,
      content: generated.summary ?? "",
      key_points: generated.key_points ?? [],
      definitions: generated.definitions ?? [],
      key_dates: generated.key_dates ?? [],
    });
    if (generated.flashcards?.length) {
      await supabase.from("flashcards").insert(
        generated.flashcards.map((f) => ({ course_id: course.id, question: f.question, answer: f.answer })),
      );
    }
    if (generated.quizzes?.length) {
      await supabase.from("quizzes").insert(
        generated.quizzes.map((q) => ({
          course_id: course.id,
          type: q.type,
          question: q.question,
          options: q.options ?? [],
          correct_answer: q.correct_answer,
          explanation: q.explanation ?? null,
        })),
      );
    }
    await bump(1);
    return { courseId: course.id as string };
  });

export const chatWithCourse = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { courseId: string; message: string }) => {
    if (!data?.courseId) throw new Error("courseId requis");
    if (!data?.message?.trim()) throw new Error("Message requis");
    return data;
  })
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const bump = await ensureQuota(supabase, userId, "chat_messages_used", FREE_LIMITS.chat_messages);
    const { data: course } = await supabase.from("courses").select("id, title").eq("id", data.courseId).eq("user_id", userId).maybeSingle();
    if (!course) throw new Error("Cours introuvable");
    const { data: transcript } = await supabase.from("transcripts").select("cleaned_text").eq("course_id", data.courseId).maybeSingle();
    const { data: history } = await supabase
      .from("chat_messages")
      .select("role, content")
      .eq("course_id", data.courseId)
      .order("created_at", { ascending: true })
      .limit(20);

    await supabase.from("chat_messages").insert({ course_id: data.courseId, user_id: userId, role: "user", content: data.message });

    const context_text = (transcript?.cleaned_text ?? "").slice(0, 15000);
    const resp = await chatCompletion({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: `Tu es un tuteur bienveillant en français. Tu réponds uniquement en te basant sur le cours suivant (titre: "${course.title}"). Si l'info n'est pas dans le cours, dis-le clairement.\n\nCOURS:\n${context_text}`,
        },
        ...(history ?? []).map((m: any) => ({ role: m.role, content: m.content })),
        { role: "user", content: data.message },
      ],
    });
    const answer = resp.choices?.[0]?.message?.content ?? "";
    await supabase.from("chat_messages").insert({ course_id: data.courseId, user_id: userId, role: "assistant", content: answer });
    await bump(1);
    return { answer };
  });