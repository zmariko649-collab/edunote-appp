export const FREE_LIMITS = {
  summaries: 5,
  flashcards: 100,
  chat_messages: 30,
  quizzes: 5,
} as const;

export function currentMonthKey(date = new Date()): string {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

export type UsageCounters = {
  summaries_used: number;
  flashcards_used: number;
  chat_messages_used: number;
  quizzes_used: number;
};