import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const redeemLicenseKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { key: string }) => {
    if (!input || typeof input.key !== "string") throw new Error("Clé invalide");
    const key = input.key.trim().toUpperCase();
    if (key.length < 6 || key.length > 64) throw new Error("Clé invalide");
    return { key };
  })
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const key = data.key;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: licence, error: fetchErr } = await supabaseAdmin
      .from("licences")
      .select("id, status, used_by")
      .eq("code", key)
      .maybeSingle();
    if (fetchErr) throw new Error("Erreur de vérification. Réessaye.");
    if (!licence) throw new Error("Clé de licence introuvable.");
    if (licence.status === "used") throw new Error("Cette clé a déjà été utilisée.");

    // Marque la clé utilisée (garde-fou concurrentiel via WHERE status = 'unused')
    const { data: claimed, error: claimErr } = await supabaseAdmin
      .from("licences")
      .update({ status: "used", used_by: userId, used_at: new Date().toISOString() })
      .eq("id", licence.id)
      .eq("status", "unused")
      .select("id")
      .maybeSingle();
    if (claimErr || !claimed) throw new Error("Cette clé n'est plus disponible.");

    const { error: profErr } = await supabaseAdmin
      .from("profiles")
      .update({ plan: "premium" })
      .eq("user_id", userId);
    if (profErr) throw new Error("Licence validée mais activation échouée. Contacte le support.");

    return { ok: true as const };
  });