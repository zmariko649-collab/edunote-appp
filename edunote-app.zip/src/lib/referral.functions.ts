import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const getMyReferrals = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: me, error: meErr } = await supabase
      .from("profiles")
      .select("referral_code, credits, plan")
      .eq("user_id", userId)
      .maybeSingle();
    if (meErr) throw new Error(meErr.message);
    if (!me?.referral_code) {
      return { code: null as string | null, credits: me?.credits ?? 0, plan: me?.plan ?? "free", referrals: [] as Array<{ full_name: string | null; email: string | null; created_at: string }> };
    }

    // Uses admin client to read filleuls (public.profiles RLS scopes to auth.uid)
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: refs, error: refsErr } = await supabaseAdmin
      .from("profiles")
      .select("full_name, email, created_at")
      .eq("referred_by", me.referral_code)
      .order("created_at", { ascending: false });
    if (refsErr) throw new Error(refsErr.message);

    return {
      code: me.referral_code,
      credits: me.credits ?? 0,
      plan: me.plan ?? "free",
      referrals: (refs ?? []).map((r) => ({
        full_name: r.full_name,
        email: maskEmail(r.email),
        created_at: r.created_at,
      })),
    };
  });

function maskEmail(email: string | null): string | null {
  if (!email) return null;
  const [user, domain] = email.split("@");
  if (!domain) return email;
  const visible = user.slice(0, 2);
  return `${visible}${"*".repeat(Math.max(1, user.length - 2))}@${domain}`;
}