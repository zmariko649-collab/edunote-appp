REVOKE SELECT ON public.leaderboard FROM anon;
DROP POLICY IF EXISTS "Leaderboard is public readable" ON public.leaderboard;
CREATE POLICY "Leaderboard readable by authenticated users"
  ON public.leaderboard FOR SELECT
  TO authenticated
  USING (true);