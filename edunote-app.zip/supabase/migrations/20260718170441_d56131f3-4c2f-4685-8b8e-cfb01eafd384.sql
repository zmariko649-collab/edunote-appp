CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  ref_code text;
  ref_user uuid;
  starting_credits int := 10;
  new_code text;
BEGIN
  ref_code := NULLIF(upper(NEW.raw_user_meta_data->>'referred_by'), '');

  IF ref_code IS NOT NULL THEN
    SELECT user_id INTO ref_user FROM public.profiles WHERE referral_code = ref_code LIMIT 1;
    IF ref_user IS NOT NULL AND ref_user <> NEW.id THEN
      starting_credits := 25;
    ELSE
      ref_code := NULL;
      ref_user := NULL;
    END IF;
  END IF;

  new_code := public.generate_referral_code();

  INSERT INTO public.profiles (user_id, full_name, email, credits, referral_code, referred_by)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
    NEW.email,
    starting_credits,
    new_code,
    ref_code
  )
  ON CONFLICT (user_id) DO NOTHING;

  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user')
  ON CONFLICT (user_id, role) DO NOTHING;

  IF NEW.email = 'zmariko649@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  IF ref_user IS NOT NULL THEN
    UPDATE public.profiles SET credits = credits + 25 WHERE user_id = ref_user;
  END IF;

  RETURN NEW;
END $function$;