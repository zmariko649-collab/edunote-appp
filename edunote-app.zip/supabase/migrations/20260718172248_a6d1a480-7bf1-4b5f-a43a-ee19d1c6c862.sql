DROP POLICY IF EXISTS "Users can lookup a licence by code" ON public.licences;
REVOKE SELECT ON public.licences FROM authenticated, anon;