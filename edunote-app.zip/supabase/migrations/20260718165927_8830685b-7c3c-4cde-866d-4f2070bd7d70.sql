-- 1. Ajouter les nouveaux champs
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS credits integer NOT NULL DEFAULT 10,
  ADD COLUMN IF NOT EXISTS referral_code text,
  ADD COLUMN IF NOT EXISTS referred_by text;

-- Générateur de code de parrainage (6 caractères A-Z 0-9)
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS text
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  chars text := 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  code text;
  i int;
  attempts int := 0;
BEGIN
  LOOP
    code := '';
    FOR i IN 1..6 LOOP
      code := code || substr(chars, 1 + floor(random() * length(chars))::int, 1);
    END LOOP;
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.profiles WHERE referral_code = code);
    attempts := attempts + 1;
    IF attempts > 20 THEN RAISE EXCEPTION 'Could not generate unique referral code'; END IF;
  END LOOP;
  RETURN code;
END $$;

-- Backfill des codes existants
UPDATE public.profiles SET referral_code = public.generate_referral_code() WHERE referral_code IS NULL;

-- Unicité + non null après backfill
ALTER TABLE public.profiles ALTER COLUMN referral_code SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS profiles_referral_code_key ON public.profiles(referral_code);

-- 2. Mise à jour du trigger handle_new_user pour intégrer parrainage
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  ref_code text;
  ref_user uuid;
  starting_credits int := 10;
  new_code text;
BEGIN
  ref_code := NULLIF(upper(NEW.raw_user_meta_data->>'referred_by'), '');

  -- Cherche le parrain
  IF ref_code IS NOT NULL THEN
    SELECT user_id INTO ref_user FROM public.profiles WHERE referral_code = ref_code LIMIT 1;
    IF ref_user IS NOT NULL AND ref_user <> NEW.id THEN
      starting_credits := 15;
    ELSE
      ref_code := NULL;
      ref_user := NULL;
    END IF;
  END IF;

  new_code := public.generate_referral_code();

  INSERT INTO public.profiles (user_id, full_name, email, credits, referral_code, referred_by)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
    NEW.email,
    starting_credits,
    new_code,
    ref_code
  )
  ON CONFLICT (user_id) DO NOTHING;

  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user')
  ON CONFLICT (user_id, role) DO NOTHING;

  IF NEW.email = 'zmariko649@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  -- Bonus parrain
  IF ref_user IS NOT NULL THEN
    UPDATE public.profiles SET credits = credits + 5 WHERE user_id = ref_user;
  END IF;

  RETURN NEW;
END $$;

-- 3. Fonction atomique pour consommer 1 crédit (utilisée côté serveur)
CREATE OR REPLACE FUNCTION public.consume_credit(_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated int;
BEGIN
  UPDATE public.profiles
  SET credits = credits - 1
  WHERE user_id = _user_id AND plan <> 'premium' AND credits > 0;
  GET DIAGNOSTICS updated = ROW_COUNT;
  RETURN updated > 0;
END $$;

REVOKE ALL ON FUNCTION public.consume_credit(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.consume_credit(uuid) TO authenticated, service_role;