
-- Remove 'youtube' value from source_type enum
ALTER TYPE public.source_type RENAME TO source_type_old;
CREATE TYPE public.source_type AS ENUM ('pdf','word','text','audio','video');
-- Update any lingering rows (should not exist, but safe)
UPDATE public.courses SET source_type = 'text'::public.source_type_old WHERE source_type = 'youtube'::public.source_type_old;
ALTER TABLE public.courses
  ALTER COLUMN source_type TYPE public.source_type
  USING source_type::text::public.source_type;
DROP TYPE public.source_type_old;
