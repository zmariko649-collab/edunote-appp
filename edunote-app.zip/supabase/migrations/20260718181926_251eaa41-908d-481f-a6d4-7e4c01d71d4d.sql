
CREATE TABLE public.leaderboard (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  score INTEGER NOT NULL DEFAULT 0,
  matiere TEXT,
  course_id UUID REFERENCES public.courses(id) ON DELETE SET NULL,
  full_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.leaderboard TO authenticated;
GRANT SELECT ON public.leaderboard TO anon;
GRANT ALL ON public.leaderboard TO service_role;

ALTER TABLE public.leaderboard ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Leaderboard is public readable"
  ON public.leaderboard FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own scores"
  ON public.leaderboard FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX leaderboard_created_at_idx ON public.leaderboard (created_at DESC);
CREATE INDEX leaderboard_score_idx ON public.leaderboard (score DESC);
