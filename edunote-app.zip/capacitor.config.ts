import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "app.lovable.edunote",
  appName: "EduNote",
  // Build web assets first (CAPACITOR=1 vite build) then `npx cap sync android`.
  webDir: "dist/client",
  android: {
    // https://localhost inside the WebView: required for secure-context APIs.
    allowMixedContent: false,
  },
  server: {
    androidScheme: "https",
  },
  plugins: {
    GoogleAuth: {
      scopes: ["profile", "email"],
      // Web client ID from Google Cloud (type "Web application").
      serverClientId: "",
      forceCodeForRefreshToken: true,
    },
  },
};

export default config;
